/* Tidekeeper: dependency-free, deterministic rules. Art remains candidate material. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.TidekeeperCore = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const VERSION = 1;
  const COLS = 5;
  const SIZE = 25;
  const PHASES = ['intro', 'wood', 'repairing', 'lantern', 'lighting', 'beacon', 'arriving', 'reward', 'complete'];
  const DURATIONS = { repairing: 2800, lighting: 2900, arriving: 5200 };
  const ITEMS = {
    w1: { name: '修缮木板', image: 'wood-l1.png', next: 'w2', level: 1, family: 'wood', value: 1 },
    w2: { name: '整捆木料', image: 'wood-l2.png', next: null, level: 2, family: 'wood', value: 2 },
    l1: { name: '口袋油灯', image: 'lamp-l1.png', next: 'l2', level: 1, family: 'lamp', value: 1 },
    l2: { name: '手提风灯', image: 'lamp-l2.png', next: 'l3', level: 2, family: 'lamp', value: 2 },
    l3: { name: '圆镜探照灯', image: 'lamp-l3.png', next: 'l4', level: 3, family: 'lamp', value: 4 },
    l4: { name: '归航灯', image: 'lamp-l4.png', next: null, level: 4, family: 'lamp', value: 8 },
    producer: { name: '灯匠工作箱', image: 'producer.png', next: null },
    locked: { name: '缠网的旧货箱', image: 'locked.png', next: null }
  };

  function initialBoard() {
    const board = Array(SIZE).fill(null);
    [1, 3, 6, 8].forEach(i => { board[i] = 'w1'; });
    board[11] = 'l1';
    board[13] = 'l1';
    board[17] = 'producer';
    for (let i = 20; i < SIZE; i++) board[i] = 'locked';
    return board;
  }

  function createState(phase = 'intro') {
    return { version: VERSION, phase, board: initialBoard(), selected: null, coins: 0,
      merges: 0, generated: 0, phaseTime: 0, elapsed: 0, undo: null };
  }
  const isBoardPhase = state => state.phase === 'wood' || state.phase === 'lantern';
  const count = (state, id) => state.board.filter(v => v === id).length;
  const familyValue = (state, family) => state.board.reduce((n, v) => n + (ITEMS[v]?.family === family ? ITEMS[v].value : 0), 0);
  const orderReady = state => state.phase === 'wood' ? count(state, 'w2') >= 2 : state.phase === 'lantern' && count(state, 'l4') >= 1;
  const copy = state => ({ ...state, board: [...state.board] });
  const snapshot = state => ({ board: [...state.board], merges: state.merges, generated: state.generated });
  const canMerge = (a, b) => !!a && a === b && !!ITEMS[a]?.next;
  const notice = (state, text) => ({ state, event: { type: 'notice', text } });

  function supply(state) {
    if (!isBoardPhase(state)) return { state, event: null };
    const slot = state.board.indexOf(null);
    if (slot < 0) return notice(state, '先合成一对，腾出空位。');
    const woodValue = familyValue(state, 'wood');
    const lampValue = familyValue(state, 'lamp');
    let item = null;
    if (state.phase === 'wood' && woodValue < 4) item = 'w1';
    else if (lampValue < (state.phase === 'wood' ? 6 : 8)) item = 'l1';
    if (!item) return notice(state, '材料已经备齐，把相同的合起来吧。');
    const next = copy(state);
    next.undo = snapshot(state);
    next.board[slot] = item;
    next.selected = null;
    next.generated++;
    return { state: next, event: { type: 'supply', to: slot, item } };
  }

  function cell(state, index, source) {
    if (!isBoardPhase(state) || !Number.isInteger(index) || index < 0 || index >= SIZE) return { state, event: null };
    const value = state.board[index];
    if (value === 'locked') return notice(state, '修好栈桥后，就能拆开这些货箱。');
    if (value === 'producer') return supply(state);
    const selected = Number.isInteger(source) ? source : state.selected;
    if (selected === index) return { state: { ...state, selected: null }, event: null };
    const from = Number.isInteger(selected) && selected >= 0 && selected < SIZE ? state.board[selected] : null;
    if (from && from !== 'locked' && from !== 'producer') {
      if (value === null) {
        const next = copy(state);
        next.undo = snapshot(state);
        next.board[index] = from;
        next.board[selected] = null;
        next.selected = null;
        return { state: next, event: { type: 'move', from: selected, to: index, item: from } };
      }
      if (canMerge(from, value)) {
        const next = copy(state);
        next.undo = snapshot(state);
        next.board[index] = ITEMS[value].next;
        next.board[selected] = null;
        next.selected = index;
        next.merges++;
        return { state: next, event: { type: 'merge', from: selected, to: index, before: value, item: next.board[index] } };
      }
      return { state: { ...state, selected: value ? index : null }, event: { type: 'notice', text: from === value ? '这件已经做好，可以交给订单了。' : '选择两件相同的物品。' } };
    }
    return { state: { ...state, selected: value ? index : null }, event: null };
  }

  function finishPhase(state) {
    const next = copy(state);
    next.phaseTime = 0;
    next.selected = null;
    next.undo = null;
    if (state.phase === 'repairing') {
      next.phase = 'lantern';
      next.board = next.board.map(v => v === 'locked' ? null : v);
      // Two lamps from the newly opened delivery. Total lamp value stays at or below eight.
      for (let n = 0; n < 2 && familyValue(next, 'lamp') < 8; n++) {
        const preferred = [21, 23][n];
        const slot = next.board[preferred] === null ? preferred : next.board.indexOf(null);
        if (slot >= 0) next.board[slot] = 'l1';
      }
      return { state: next, event: { type: 'repaired' } };
    }
    if (state.phase === 'lighting') {
      next.phase = 'beacon';
      return { state: next, event: { type: 'lit' } };
    }
    if (state.phase === 'arriving') {
      next.phase = 'reward';
      return { state: next, event: { type: 'arrived' } };
    }
    return { state, event: null };
  }

  function act(state, action, value) {
    if (action === 'restart') return { state: createState('wood'), event: { type: 'start' } };
    if (action === 'start' && state.phase === 'intro') return { state: { ...state, phase: 'wood' }, event: { type: 'start' } };
    if (action === 'cell') return cell(state, Number(value));
    if (action === 'drag') return cell(state, Number(value?.to), Number(value?.from));
    if (action === 'supply') return supply(state);
    if (action === 'clear') return { state: { ...state, selected: null }, event: null };
    if (action === 'undo' && isBoardPhase(state) && state.undo) {
      return { state: { ...state, ...state.undo, board: [...state.undo.board], undo: null, selected: null }, event: { type: 'undo' } };
    }
    if (action === 'deliver' && state.phase === 'wood') {
      if (!orderReady(state)) return notice(state, '还需要两捆木料。');
      const next = copy(state);
      for (let i = 0; i < 2; i++) next.board[next.board.indexOf('w2')] = null;
      Object.assign(next, { phase: 'repairing', phaseTime: 0, selected: null, undo: null, coins: next.coins + 25 });
      return { state: next, event: { type: 'repair' } };
    }
    if (action === 'light' && state.phase === 'lantern') {
      if (!orderReady(state)) return notice(state, '把灯具合成到四级。');
      const next = copy(state);
      next.board[next.board.indexOf('l4')] = null;
      Object.assign(next, { phase: 'lighting', phaseTime: 0, selected: null, undo: null, coins: next.coins + 30 });
      return { state: next, event: { type: 'light' } };
    }
    if (action === 'beckon' && state.phase === 'beacon') {
      return { state: { ...state, phase: 'arriving', phaseTime: 0 }, event: { type: 'beckon' } };
    }
    if (action === 'claim' && state.phase === 'reward') {
      return { state: { ...state, phase: 'complete', coins: state.coins + 50 }, event: { type: 'win' } };
    }
    if (action === 'finish' && DURATIONS[state.phase]) return finishPhase(state);
    return { state, event: null };
  }

  function step(state, delta) {
    const dt = Number.isFinite(delta) ? Math.max(0, Math.min(60000, delta)) : 0;
    if (!dt || state.phase === 'intro' || state.phase === 'complete') return { state, event: null };
    const next = { ...state, elapsed: state.elapsed + dt };
    if (!DURATIONS[state.phase]) return { state: next, event: null };
    next.phaseTime += dt;
    if (next.phaseTime >= DURATIONS[state.phase]) return finishPhase(next);
    return { state: next, event: null };
  }

  function validBoard(board) {
    return Array.isArray(board) && board.length === SIZE && board.every(v => v === null || Object.prototype.hasOwnProperty.call(ITEMS, v)) && board.filter(v => v === 'producer').length === 1;
  }

  function restore(raw) {
    try {
      const input = typeof raw === 'string' ? JSON.parse(raw) : raw;
      if (!input || input.version !== VERSION || !PHASES.includes(input.phase) || !validBoard(input.board)) return null;
      const early = input.phase === 'intro' || input.phase === 'wood';
      if (early && (familyValue(input, 'wood') !== 4 || familyValue(input, 'lamp') < 2 || familyValue(input, 'lamp') > 6)) return null;
      if (!early && familyValue(input, 'wood') !== 0) return null;
      if (input.phase === 'repairing' && (familyValue(input, 'lamp') < 2 || familyValue(input, 'lamp') > 6)) return null;
      if (input.phase === 'lantern' && (familyValue(input, 'lamp') < 4 || familyValue(input, 'lamp') > 8)) return null;
      if (['lighting', 'beacon', 'arriving', 'reward', 'complete'].includes(input.phase) && familyValue(input, 'lamp') !== 0) return null;
      const shouldLock = early || input.phase === 'repairing';
      if (input.board.filter(v => v === 'locked').length !== (shouldLock ? 5 : 0)) return null;
      if (shouldLock && !input.board.slice(20).every(v => v === 'locked')) return null;
      const phase = input.phase;
      const coins = ['intro', 'wood'].includes(phase) ? 0 : ['repairing', 'lantern'].includes(phase) ? 25 : phase === 'complete' ? 105 : 55;
      return {
        version: VERSION, phase, board: [...input.board], selected: null, coins,
        merges: Math.max(0, Math.min(9999, Math.floor(Number(input.merges) || 0))),
        generated: Math.max(0, Math.min(9999, Math.floor(Number(input.generated) || 0))),
        phaseTime: Math.max(0, Math.min(DURATIONS[phase] || 0, Number(input.phaseTime) || 0)),
        elapsed: Math.max(0, Math.min(86400000, Number(input.elapsed) || 0)), undo: null
      };
    } catch (_) { return null; }
  }

  function serialize(state) { return JSON.stringify({ ...state, selected: null, undo: null }); }
  function nextPair(state) {
    const priority = state.phase === 'wood' ? ['w1', 'l1', 'l2', 'l3'] : ['l3', 'l2', 'l1', 'w1'];
    for (const value of priority) {
      const first = state.board.indexOf(value);
      const second = state.board.indexOf(value, first + 1);
      if (first >= 0 && second >= 0) return [first, second];
    }
    return null;
  }

  return { VERSION, COLS, SIZE, PHASES, DURATIONS, ITEMS, createState, isBoardPhase, count, familyValue, orderReady, canMerge, act, step, restore, serialize, nextPair };
});
