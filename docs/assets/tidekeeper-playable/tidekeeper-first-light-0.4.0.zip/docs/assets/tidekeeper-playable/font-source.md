# 潮灯小镇字体来源

本文件对应 `tide-sans.woff2`，状态为 candidate；未取得人工主美批准。

- 字体：Noto Sans SC 2.004，正常体，可变字重 100–900。沿用现有港湾 UI 字体，未修改字形设计。
- 来源：[Google Fonts 官方目录](https://github.com/google/fonts/tree/main/ofl/notosanssc)；[源字体](https://raw.githubusercontent.com/google/fonts/main/ofl/notosanssc/NotoSansSC%5Bwght%5D.ttf)。
- 源文件 SHA256：`a3041811a78c361b1de50f953c805e0244951c21c5bd412f7232ef0d899af0da`。本次使用已有本地完整源；与官方 GitHub contents API 的 Git blob `fb0637bafbcd804fe32152370a1225990745b4bc` 核对一致。
- 授权：[SIL Open Font License 1.1](https://raw.githubusercontent.com/google/fonts/main/ofl/notosanssc/OFL.txt)，副本见同目录 `OFL.txt`；版权与字体内部许可字段保留。
- 构建：fontTools 4.61.1 的 `subset`，保留所有布局特性、名称与语言字段、完整可变字重轴；导出 WOFF2。
- 字符：当前游戏 HTML/CSS/JS 中的中文、原有字体全部 687 个 Unicode 映射、ASCII 32–126，以及修缮、归航、帮助与常见后续操作短文案。覆盖与源文件哈希详见 `evals/tidekeeper-playable/font-verification.json`。
- 原字体不含撤销符号 U+21B6 `↶`。最终 UI 已采用内联 SVG；没有把其他字形重映射成该符号。

游戏已保持现有 `font-family: TideSans`，把 `@font-face` 指向同目录 `url('./tide-sans.woff2') format('woff2')`，保留 `font-weight: 100 900` 与 `font-display: swap`，并预加载此字体。

字形轮廓和字宽在 100、400、700、900 字重对照旧字体检查通过；属于技术验证。最终界面缩放、文字布局和可读性由游戏组合验收记录。新增文案后需再次检查字符覆盖；此文件不宣称覆盖完整简体中文字库。
