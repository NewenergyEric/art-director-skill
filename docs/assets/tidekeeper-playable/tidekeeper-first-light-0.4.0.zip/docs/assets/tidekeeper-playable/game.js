(function () {
  'use strict';
  const C = window.TidekeeperCore;
  if (!C) return;
  const ART = '../tidekeeper-production/';
  const SAVE_KEY = 'tidekeeper-first-light-v1';
  const PREF_KEY = 'tidekeeper-first-light-sound';
  const $ = id => document.getElementById(id);
  const game = $('game'), board = $('board'), canvas = $('scene');
  const ctx = canvas.getContext('2d');
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const images = new Map();
  const assetErrors = [];
  // Static narrative poses, not animation frames. Alpha bounds and both sole anchors
  // were measured from the original PNGs with Pillow at alpha > 32 (2026-10-13).
  // Each visible silhouette is 280 world pixels tall; the lowest sole lands at y=864.
  const STATIC_POSES = {
    'character-base.png': { size: [768, 1152], alphaBounds: [209, 107, 565, 1039], ground: [381.101, 1038], feet: [[255.927, 1038, 81], [506.276, 1021, 77]] },
    'character-signal.png': { size: [640, 960], alphaBounds: [138, 56, 571, 927], ground: [329.172, 926], feet: [[182.930, 926, 77], [475.414, 907, 77]] },
    'character-wave.png': { size: [768, 1152], alphaBounds: [213, 184, 542, 975], ground: [384.687, 974], feet: [[278.620, 974, 72], [490.753, 960, 70]] }
  };
  let state = loadSave() || C.createState();
  let soundEnabled = loadPreference();
  let audioContext = null;
  let dialog = null;
  let lastFocus = null;
  let focusedCell = 1;
  let pointer = null;
  let suppressClickUntil = 0;
  let toastUntil = 0;
  let hintUntil = 0;
  let hintPair = null;
  let presentationTime = 0;
  let lastFrame = performance.now();
  let savedAt = 0;
  let manualUntil = 0;
  let lastRepairFrame = -1;
  let ready = false;
  let cssWidth = 0, cssHeight = 0;
  let fxTimers = [];

  function loadSave() {
    try { return C.restore(localStorage.getItem(SAVE_KEY)); } catch (_) { return null; }
  }
  function loadPreference() {
    try { return localStorage.getItem(PREF_KEY) !== 'off'; } catch (_) { return true; }
  }
  function save() {
    try { localStorage.setItem(SAVE_KEY, C.serialize(state)); } catch (_) { /* The game remains playable in a private or full store. */ }
  }
  function preload(src) {
    if (images.has(src)) return Promise.resolve(images.get(src));
    const image = new Image();
    images.set(src, image);
    image.decoding = 'async';
    return new Promise(resolve => {
      image.onload = () => resolve(image);
      image.onerror = () => { assetErrors.push(src); resolve(null); };
      image.src = src;
    });
  }
  const escapeHtml = value => String(value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const itemImage = (id, className = '', alt = '') => `<img class="${className}" src="${ART + C.ITEMS[id].image}" alt="${escapeHtml(alt)}" draggable="false">`;
  const isBusy = () => !!C.DURATIONS[state.phase];
  const isFocusedScene = () => !['intro', 'wood', 'lantern'].includes(state.phase);

  function animationData() {
    const manifest = window.TIDEKEEPER_ANIMATION;
    const repair = manifest?.repair || manifest?.animations?.repair || (manifest?.frames ? manifest : null);
    if (!repair?.frames?.length) return null;
    return repair;
  }
  function frameSource(frame) { return typeof frame === 'string' ? frame : frame.src || frame.path || frame.image; }
  function frameDuration(frame, animation) { return Math.max(25, Number(frame?.duration ?? frame?.durationMs ?? animation.frameDuration ?? animation.frameDurationMs) || 120); }
  function repairFrame(time) {
    const animation = animationData();
    if (!animation) return { src: ART + 'character-repair.png', index: -1, box: [385, 540, 225, 337.5], sinceHit: -1, contact: [498, 849] };
    const duration = animation.frames.reduce((sum, frame) => sum + frameDuration(frame, animation), 0);
    const animationTime = Math.min(Math.max(0, time), duration * (animation.loops || 2) - .01);
    const loopTime = animationTime % duration;
    let elapsed = 0, index = 0, contactStart = 0;
    const markedImpacts = animation.frames.map((frame, i) => frame.impact ? i : -1).filter(i => i >= 0);
    const contactFrames = animation.contactFrames || (markedImpacts.length ? markedImpacts : [animation.contactFrame ?? Math.floor(animation.frames.length * .5)]);
    for (let i = 0; i < animation.frames.length; i++) {
      if (contactFrames.includes(i)) contactStart = elapsed;
      const d = frameDuration(animation.frames[i], animation);
      if (loopTime >= elapsed && loopTime < elapsed + d) index = i;
      elapsed += d;
    }
    const frame = animation.frames[index];
    const box = animation.displayBox || animation.box || [385, 540, 225, 337.5];
    const contact = frame?.contactWorld || animation.contactWorld || animation.contact || [498, 849];
    return { src: frameSource(frame), index, box, contact, sinceHit: (loopTime - contactStart + duration) % duration, contactFrames };
  }

  function sound(name) {
    if (!soundEnabled || !audioContext) return;
    const ac = audioContext;
    if (ac.state === 'suspended') ac.resume().catch(() => {});
    const now = ac.currentTime;
    const note = (frequency, duration, start, volume = .027, type = 'sine') => {
      const osc = ac.createOscillator(), gain = ac.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(frequency, now + start);
      gain.gain.setValueAtTime(0, now + start);
      gain.gain.linearRampToValueAtTime(volume, now + start + .009);
      gain.gain.exponentialRampToValueAtTime(.0001, now + start + duration);
      osc.connect(gain); gain.connect(ac.destination);
      osc.start(now + start); osc.stop(now + start + duration + .015);
    };
    if (name === 'merge') { note(523.25, .15, 0); note(783.99, .26, .065, .023); }
    else if (name === 'wood') { note(190, .085, 0, .035, 'triangle'); note(110, .065, .025, .025, 'triangle'); }
    else if (name === 'supply') note(392, .17, 0, .02);
    else if (name === 'win' || name === 'lit') [523.25, 659.25, 783.99, 1046.5].forEach((f, i) => note(f, .54, i * .105, .022));
    else if (name === 'arrived') [261.63, 392, 523.25].forEach((f, i) => note(f, .7, i * .13, .02, 'triangle'));
    else if (name === 'start') note(523.25, .25, 0, .018);
  }
  function unlockAudio() {
    if (!soundEnabled) return;
    if (!audioContext) {
      const Audio = window.AudioContext || window.webkitAudioContext;
      if (Audio) { try { audioContext = new Audio(); } catch (_) { return; } }
    }
    if (audioContext?.state === 'suspended') audioContext.resume().catch(() => {});
  }
  function renderSound() {
    $('sound-button').innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M11 5 6 9H3v6h3l5 4V5Z"/>${soundEnabled ? '<path d="M15 8a6 6 0 0 1 0 8M18 5a10 10 0 0 1 0 14"/>' : '<path d="m16 9 5 6m0-6-5 6"/>'}</svg>`;
    $('sound-button').setAttribute('aria-label', soundEnabled ? '关闭声音' : '打开声音');
    $('sound-button').setAttribute('aria-pressed', String(soundEnabled));
  }

  function tell(message, duration = 2600) {
    $('toast').textContent = message;
    $('toast').classList.add('visible');
    toastUntil = presentationTime + duration;
  }
  function dispatch(action, value) {
    const result = C.act(state, action, value);
    if (result.state === state && !result.event) return;
    const old = state;
    state = result.state;
    if (old.phase !== state.phase) {
      lastRepairFrame = -1;
      if (state.phase === 'repairing' || state.phase === 'lighting') {
        toastUntil = 0;
        $('toast').classList.remove('visible');
        $('toast').textContent = '';
      }
      if (isFocusedScene()) {
        hintPair = null;
        cancelDrag();
      }
    }
    renderUI();
    save();
    handleEvent(result.event);
    if (reducedMotion && isBusy()) dispatch('finish');
    drawScene();
  }
  function handleEvent(event) {
    if (!event) return;
    if (event.type === 'notice') { tell(event.text); return; }
    if (event.type === 'merge') {
      sound(event.before === 'w1' ? 'wood' : 'merge');
      mergeEffect(event);
      if (C.orderReady(state)) tell(state.phase === 'wood' ? '木料齐了，可以修栈桥了。' : '归航灯做好了。', 2400);
    }
    if (event.type === 'move') {
      const target = board.querySelector(`[data-cell="${event.to}"]`);
      target?.classList.add('supply-pop');
    }
    if (event.type === 'supply') {
      sound('supply');
      board.querySelector(`[data-cell="${event.to}"]`)?.classList.add('supply-pop');
    }
    if (event.type === 'repaired') { tell('货箱打开了，里面还有两盏小油灯。', 3200); sound('merge'); }
    if (event.type === 'lit' || event.type === 'arrived' || event.type === 'start') sound(event.type);
    if (event.type === 'win') { sound('win'); showDialog('win'); }
    if (event.type === 'start') { hideDialog(); $('board').querySelector('[data-cell="1"]')?.focus({ preventScroll: true }); }
  }

  function renderOrder() {
    const phase = state.phase;
    if (phase === 'wood' || phase === 'intro' || phase === 'lantern') {
      const wood = phase !== 'lantern', item = wood ? 'w2' : 'l4';
      const have = Math.min(wood ? 2 : 1, C.count(state, item)), need = wood ? 2 : 1;
      const can = have >= need;
      $('order').innerHTML = `<div class="order-portrait ${wood ? '' : 'alan'}"><img src="${ART}${wood ? 'neri.png' : 'character-base.png'}" alt="${wood ? '奈莉' : '阿澜'}"></div><div class="order-copy"><span class="order-person">${wood ? '奈莉的订单' : '阿澜的订单'}</span><h1>${wood ? '给栈桥换上新木板' : '点亮第一盏归航灯'}</h1><div class="order-bottom"><span class="order-reward"><img src="${ART}coin.png" alt="贝壳金币">+${wood ? 25 : 30}</span><button class="action-button" data-action="${wood ? 'deliver' : 'light'}" ${can && phase !== 'intro' ? '' : 'disabled'}>${can ? wood ? '交付木料' : '点亮灯房' : wood ? '合成木料' : '合成四级灯'}</button></div></div><div class="order-target">${itemImage(item)}<span class="order-count ${can ? 'ready' : ''}" aria-label="${have}，需要${need}">${have}/${need}</span></div>`;
      return;
    }
    const details = {
      repairing: ['w2', '新木板，要钉牢。', '阿澜正在补好栈桥。'],
      lighting: ['l4', '第一束光，亮起来。', '灯光正在铺向海面。'],
      beacon: ['l4', '海上还有一艘船。', '招呼它，今晚在这里靠岸。'],
      arriving: ['l4', '看，船回来了。', '新的木料和灯油正在靠岸。'],
      reward: ['producer', '欢迎回到小镇。', '船长为灯匠留了一份礼物。'],
      complete: ['l4', '灯房重新开门了。', '下一段故事，明天再继续。']
    }[phase];
    $('order').innerHTML = `<div class="order-story">${itemImage(details[0])}<div><strong>${details[1]}</strong><p>${details[2]}</p></div></div>`;
  }

  function renderBoard() {
    const previousFocus = document.activeElement?.dataset?.cell;
    const selected = state.selected === null ? null : state.board[state.selected];
    const interactive = C.isBoardPhase(state);
    board.classList.toggle('inactive', !interactive);
    board.innerHTML = state.board.map((value, index) => {
      const info = C.ITEMS[value];
      const isSelected = state.selected === index;
      const matches = selected && selected === value && index !== state.selected && info?.next;
      const order = (state.phase === 'wood' && value === 'w2') || (state.phase === 'lantern' && value === 'l4');
      const classes = ['cell', value === 'locked' ? 'locked' : '', value === 'producer' ? 'producer' : '', isSelected ? 'selected' : '', matches ? 'match' : '', hintPair?.includes(index) && hintUntil > presentationTime ? 'hint' : ''].filter(Boolean).join(' ');
      return `<button class="${classes}" data-cell="${index}" tabindex="${index === focusedCell ? 0 : -1}" ${value === 'locked' || !interactive ? 'disabled' : ''} aria-label="第${Math.floor(index / 5) + 1}行第${index % 5 + 1}格，${info?.name || '空位'}${info?.level ? `，${info.level}级` : ''}${order ? '，订单需要' : ''}" aria-pressed="${isSelected}">${value ? itemImage(value) : ''}${info?.level ? `<span class="level" aria-hidden="true">${info.level}</span>` : ''}${value === 'producer' ? '<span class="producer-plus" aria-hidden="true">+</span>' : ''}${order ? '<span class="order-check" aria-hidden="true">✓</span>' : ''}</button>`;
    }).join('');
    if (previousFocus !== undefined && interactive) board.querySelector(`[data-cell="${previousFocus}"]`)?.focus({ preventScroll: true });
    $('undo-button').disabled = !state.undo || !interactive;
    $('hint-button').disabled = !interactive;
  }
  function renderInfo() {
    const selected = state.selected === null ? null : state.board[state.selected];
    const wood = state.phase === 'wood' || state.phase === 'intro';
    const item = selected || (wood ? 'w1' : 'producer');
    const info = C.ITEMS[item];
    const max = item === 'w2' || item === 'l4';
    const description = max ? '做好了，交给上方的订单。' : item === 'producer' ? '轻点工作箱，取出一盏小油灯。' : '两个相同物品，合成一个新物品。';
    const chain = wood ? ['w1', 'w2'] : ['l1', 'l2', 'l3', 'l4'];
    $('item-info').innerHTML = `${itemImage(item, 'info-image')}<div class="info-copy"><strong>${info.name}</strong><p>${description}</p></div><div class="chain" aria-label="${wood ? '木板合成木料' : '灯具从一级合成到四级'}">${chain.map((value, i) => (i ? '<span>›</span>' : '') + itemImage(value, value === selected ? 'current' : '')).join('')}</div>`;
  }
  function renderSceneCopy() {
    const phase = state.phase;
    const chapters = {
      intro: ['第一章', '旧灯房'], wood: ['第一章', '修好栈桥'], repairing: ['第一章', '修好栈桥'],
      lantern: ['第二章', '第一盏灯'], lighting: ['第二章', '第一盏灯'], beacon: ['第三章', '等待归航'],
      arriving: ['第三章', '等待归航'], reward: ['第三章', '欢迎回家'], complete: ['第三章', '欢迎回家']
    }[phase];
    $('chapter-label').textContent = chapters[0]; $('chapter-name').textContent = chapters[1];
    const captions = {
      intro: ['海风里，一间旧灯房。', ''], wood: ['海风里，一间旧灯房。', '先让摇晃的栈桥稳下来。'],
      repairing: ['一块一块，钉回原处。', ''], lantern: ['栈桥稳了，还缺一盏灯。', '从小油灯开始，慢慢合成。'],
      lighting: ['灯房的第一个夜晚。', ''], beacon: ['让船看见这束光。', '海雾里，船长正在寻找码头。'],
      arriving: ['顺着灯光，回家。', ''], reward: ['欢迎回家。', '船长带来了新木料和灯油。'],
      complete: ['今夜，小镇有了灯。', '栈桥、灯房和第一艘归船。']
    }[phase];
    $('scene-caption').innerHTML = `<h2>${captions[0]}</h2>${captions[1] ? `<p class="secondary-caption">${captions[1]}</p>` : ''}`;
    const controls = $('scene-controls');
    if (C.DURATIONS[phase]) controls.innerHTML = `<div class="scene-status">${phase === 'repairing' ? '正在修缮' : phase === 'lighting' ? '正在点灯' : '缓缓靠岸'}</div><div class="progress" role="progressbar" aria-label="${phase === 'repairing' ? '修缮' : phase === 'lighting' ? '点灯' : '归航'}进度" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><span></span></div><button class="skip" data-action="finish">略过</button>`;
    else if (phase === 'beacon') controls.innerHTML = '<button class="scene-button" data-action="beckon">招呼归船 <span aria-hidden="true">→</span></button>';
    else if (phase === 'reward') controls.innerHTML = `<button class="scene-button" data-action="claim"><img src="${ART}coin.png" alt="">领取归航礼物 +50</button>`;
    else if (phase === 'complete') controls.innerHTML = '<button class="scene-button" data-action="restart">再玩一次</button>';
    else controls.innerHTML = '';
    $('scene-caption').hidden = controls.childElementCount > 0;
    canvas.setAttribute('aria-label', `${chapters[1]}：${captions[0]}`);
  }
  function renderUI() {
    $('coins').textContent = String(state.coins);
    game.classList.toggle('scene-focused', isFocusedScene());
    game.dataset.phase = state.phase;
    renderOrder(); renderBoard(); renderInfo(); renderSceneCopy();
    updateProgress();
  }
  function updateProgress() {
    const progress = $('scene-controls').querySelector('.progress');
    if (!progress) return;
    const value = Math.min(100, state.phaseTime / C.DURATIONS[state.phase] * 100);
    progress.firstElementChild.style.width = `${value}%`;
    progress.setAttribute('aria-valuenow', String(Math.round(value)));
  }

  function clearEffects() {
    fxTimers.forEach(clearTimeout); fxTimers = [];
    $('board-effects').replaceChildren();
  }
  function mergeEffect(event) {
    if (reducedMotion) return;
    const from = board.querySelector(`[data-cell="${event.from}"]`), to = board.querySelector(`[data-cell="${event.to}"]`);
    if (!from || !to) return;
    const area = $('board-effects'), bounds = area.getBoundingClientRect(), a = from.getBoundingClientRect(), b = to.getBoundingClientRect();
    const flight = document.createElement('img');
    flight.src = ART + C.ITEMS[event.before].image;
    flight.className = 'merge-flight';
    Object.assign(flight.style, { left: `${a.left - bounds.left + 4}px`, top: `${a.top - bounds.top + 4}px`, width: `${a.width - 8}px`, height: `${a.height - 8}px` });
    flight.style.setProperty('--dx', `${b.left - a.left}px`); flight.style.setProperty('--dy', `${b.top - a.top}px`);
    area.append(flight); to.classList.add('pop');
    const x = b.left - bounds.left + b.width / 2, y = b.top - bounds.top + b.height / 2;
    fxTimers.push(setTimeout(() => {
      const ring = document.createElement('i'); ring.className = 'merge-ring'; ring.style.left = `${x}px`; ring.style.top = `${y}px`; area.append(ring);
      for (let i = 0; i < 7; i++) {
        const spark = document.createElement('i'); spark.className = 'merge-spark'; spark.style.left = `${x}px`; spark.style.top = `${y}px`;
        spark.style.setProperty('--dx', `${Math.cos(i * 2.4) * (28 + i * 3)}px`); spark.style.setProperty('--dy', `${Math.sin(i * 2.4) * (28 + i * 3)}px`);
        area.append(spark); fxTimers.push(setTimeout(() => spark.remove(), 550));
      }
      fxTimers.push(setTimeout(() => ring.remove(), 500));
    }, 140));
    fxTimers.push(setTimeout(() => flight.remove(), 250));
  }

  function getImage(src) { const image = images.get(src); return image?.complete && image.naturalWidth > 0 ? image : null; }
  const clamp = (v, min = 0, max = 1) => Math.min(max, Math.max(min, v));
  const smooth = v => { const t = clamp(v); return t * t * (3 - 2 * t); };
  function drawImage(src, box, alpha = 1, flip = false) {
    const image = getImage(src);
    if (!image || alpha <= 0) return;
    ctx.save(); ctx.globalAlpha = alpha;
    if (flip) { ctx.translate(box[0] + box[2], box[1]); ctx.scale(-1, 1); ctx.drawImage(image, 0, 0, box[2], box[3]); }
    else ctx.drawImage(image, ...box);
    ctx.restore();
  }
  function ellipse(x, y, rx, ry, color, opacity = 1) {
    ctx.save(); ctx.globalAlpha = opacity; ctx.fillStyle = color; ctx.beginPath(); ctx.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2); ctx.fill(); ctx.restore();
  }
  function glow(x, y, radius, opacity) {
    ctx.save(); ctx.globalAlpha = opacity; const gradient = ctx.createRadialGradient(x, y, 0, x, y, radius);
    gradient.addColorStop(0, '#ffecaecc'); gradient.addColorStop(.34, '#f8c46359'); gradient.addColorStop(1, '#f8c46300');
    ctx.fillStyle = gradient; ctx.fillRect(x - radius, y - radius, radius * 2, radius * 2); ctx.restore();
  }
  function staticPosePlacement(file) {
    const pose = STATIC_POSES[file];
    const scale = 280 / (pose.alphaBounds[3] - pose.alphaBounds[1]);
    const box = [498 - pose.ground[0] * scale, 864 - pose.ground[1] * scale, pose.size[0] * scale, pose.size[1] * scale];
    return { box, feet: pose.feet.map(foot => [box[0] + foot[0] * scale, box[1] + foot[1] * scale, foot[2] * scale]) };
  }
  function drawStaticPose(file, lit) {
    const placement = staticPosePlacement(file);
    // Separate sole shadows follow the measured foot contact positions of each pose.
    for (const [x, y, width] of placement.feet) ellipse(x, y + 1, width * .66, 4, '#334c45', lit ? .27 : .18);
    drawImage(ART + file, placement.box);
  }
  function drawScene() {
    if (!ctx || !ready) return;
    const bounds = canvas.getBoundingClientRect();
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    if (cssWidth !== bounds.width || cssHeight !== bounds.height || canvas.width !== Math.round(bounds.width * ratio)) {
      cssWidth = bounds.width; cssHeight = bounds.height;
      canvas.width = Math.max(1, Math.round(cssWidth * ratio)); canvas.height = Math.max(1, Math.round(cssHeight * ratio));
    }
    const scale = isFocusedScene() ? Math.max(canvas.width / 900, canvas.height / 1600) : canvas.width / 900;
    const viewHeight = canvas.height / scale, left = (canvas.width - 900 * scale) / 2;
    const top = clamp((1600 - viewHeight) * .43, 0, 370);
    ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.setTransform(scale, 0, 0, scale, left, -top * scale);
    const phase = state.phase, time = state.phaseTime;
    const repaired = !['intro', 'wood', 'repairing'].includes(phase);
    const lit = ['lighting', 'beacon', 'arriving', 'reward', 'complete'].includes(phase);
    const night = phase === 'lighting' ? smooth(time / C.DURATIONS.lighting) : lit ? 1 : 0;
    drawImage(ART + (repaired ? 'workshop-after-portrait.jpg' : 'workshop-before-portrait.jpg'), [0, 0, 900, 1600]);
    if (phase === 'repairing') drawImage(ART + 'workshop-after-portrait.jpg', [0, 0, 900, 1600], smooth((time / C.DURATIONS.repairing - .62) / .38));
    if (lit) drawImage(ART + 'workshop-night.jpg', [0, 0, 900, 1600], night);

    if (phase === 'repairing') {
      const frame = repairFrame(time);
      const box = frame.box;
      ellipse(box[0] + box[2] * .5, box[1] + box[3] * .955, box[2] * .3, 9, '#394644', .18);
      drawImage(frame.src, box);
      drawImage(ART + 'wood-l2.png', [625, 850, 108, 108], .96);
      if (frame.sinceHit >= 0 && frame.sinceHit < 225) {
        const p = frame.sinceHit / 225;
        for (let i = 0; i < 5; i++) ellipse(frame.contact[0] + Math.cos(i * 2.4) * p * 31, frame.contact[1] - p * (16 + i * 3), 3 + p * 6, 2 + p * 3, i % 2 ? '#dbbc88' : '#f6dfad', .62 * (1 - p));
      }
      if (frame.index !== lastRepairFrame) {
        if (frame.contactFrames?.includes(frame.index)) sound('wood');
        lastRepairFrame = frame.index;
      }
    } else if (phase !== 'intro') {
      const signaling = ['beacon', 'arriving', 'reward'].includes(phase);
      const actor = phase === 'complete' ? 'character-wave.png' : signaling ? 'character-signal.png' : 'character-base.png';
      drawStaticPose(actor, lit);
    }

    // This beacon does not exist in the world until the player actually delivers it.
    if (lit) {
      const appearing = phase === 'lighting' ? smooth(time / 700) : 1;
      drawImage(ART + 'lamp-l4.png', [554, 850, 112, 112], appearing);
      glow(610, 902, 81, .45 * night);
      glow(406, 518, 92, .22 * night);
    }
    if (phase === 'arriving' || phase === 'reward' || phase === 'complete') {
      const t = phase === 'arriving' ? smooth(time / C.DURATIONS.arriving) : 1;
      const x = -410 + 490 * t, y = 1370 - 335 * t;
      ctx.save(); ctx.strokeStyle = '#d2e8ca'; ctx.lineWidth = 4; ctx.lineCap = 'round'; ctx.globalAlpha = phase === 'arriving' ? .48 : .17;
      ctx.beginPath(); ctx.moveTo(x + 40, y + 173); ctx.quadraticCurveTo(x + 173, y + 227, x + 351, y + 172); ctx.stroke();
      ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x + 24, y + 189); ctx.quadraticCurveTo(x + 159, y + 250, x + 326, y + 201); ctx.stroke(); ctx.restore();
      ellipse(x + 204, y + 178, 154, 25, '#164e64', .14);
      drawImage(ART + 'supply-boat.png', [x, y, 370, 246.67], 1, true);
    }
    if (lit && !reducedMotion) {
      ctx.save(); ctx.strokeStyle = '#c6e3c6'; ctx.lineCap = 'round'; ctx.lineWidth = 2.5;
      for (let i = 0; i < 6; i++) {
        ctx.globalAlpha = (.07 + .05 * Math.sin(presentationTime / 1200 + i)) * night;
        const x = 36 + i * 134, y = 1258 + i % 3 * 57;
        ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + 18 + i % 2 * 15, y); ctx.stroke();
      }
      ctx.restore();
    }
  }

  function showDialog(kind) {
    if (!dialog) lastFocus = document.activeElement;
    dialog = kind;
    game.inert = true;
    const overlay = $('overlay');
    overlay.hidden = false; document.body.classList.add('modal-open');
    if (kind === 'intro') {
      overlay.innerHTML = `<section class="dialog intro-dialog" role="dialog" aria-modal="true" aria-labelledby="intro-title"><div class="intro-scene"><img class="intro-harbor" src="${ART}workshop-before-portrait.jpg" alt="旧灯房与待修的栈桥"><img class="intro-person" src="${ART}character-base.png" alt="灯匠阿澜"><span class="intro-brand">潮灯小镇</span></div><div class="intro-body"><span class="intro-kicker">第一段故事</span><h1 id="intro-title">第一盏归航灯</h1><p>修好栈桥，点亮灯房。<br>海上的船，等着回家。</p><div class="intro-actions"><button class="action-button" id="start-button" data-action="start">一起开工 <span aria-hidden="true">→</span></button><span class="intro-controls">点击或拖动<br>合成相同物品</span></div></div></section>`;
    } else if (kind === 'help') {
      overlay.innerHTML = `<section class="dialog" role="dialog" aria-modal="true" aria-labelledby="help-title"><button class="dialog-close" data-action="close-dialog" aria-label="关闭">×</button><h2 id="help-title">灯匠的小手册</h2><ul class="help-steps"><li>${itemImage('w1')}<span><strong>合成</strong><br>先选一件，再点相同物品。也可以拖到一起。</span></li><li>${itemImage('producer')}<span><strong>取材料</strong><br>轻点工作箱，拿出新的小油灯。</span></li><li>${itemImage('l4')}<span><strong>完成订单</strong><br>合好木料和归航灯，让港湾热闹起来。</span></li></ul><p class="help-keyboard">方向键移动选择 · 回车或空格操作<br>Esc 取消选择 · F 全屏</p><div class="dialog-footer"><button class="action-button" data-action="close-dialog">继续开工</button><button class="secondary-button" data-action="ask-restart">重新开始</button></div></section>`;
    } else if (kind === 'restart') {
      overlay.innerHTML = '<section class="dialog" role="dialog" aria-modal="true" aria-labelledby="restart-title"><h2 id="restart-title">重新开工？</h2><p>这次会从旧栈桥重新开始。</p><div class="dialog-footer"><button class="action-button" data-action="restart">重新开始</button><button class="secondary-button" data-action="close-dialog">继续这一局</button></div></section>';
    } else if (kind === 'win') {
      overlay.innerHTML = `<section class="dialog win-dialog" role="dialog" aria-modal="true" aria-labelledby="win-title">${itemImage('l4', 'win-emblem')}<span class="intro-kicker">第一段故事 · 完成</span><h2 id="win-title">第一艘船，回家了。</h2><p>木板钉稳了，窗里亮起了暖光。<br>今晚的港湾，又有了故事。</p><div class="win-reward"><img src="${ART}coin.png" alt="贝壳金币">归航礼物 +50</div><div class="win-stat">完成 ${state.merges} 次合成</div><div class="win-actions"><button class="action-button" data-action="close-dialog">看看港湾</button><button class="secondary-button" data-action="restart">再玩一次</button></div></section>`;
    }
    requestAnimationFrame(() => overlay.querySelector('.action-button,button')?.focus({ preventScroll: true }));
  }
  function hideDialog() {
    game.inert = false;
    dialog = null; $('overlay').hidden = true; $('overlay').replaceChildren(); document.body.classList.remove('modal-open');
    if (lastFocus?.isConnected) lastFocus.focus({ preventScroll: true });
    lastFocus = null;
  }
  function perform(action, value) {
    unlockAudio();
    if (action === 'close-dialog') { hideDialog(); return; }
    if (action === 'ask-restart') { showDialog('restart'); return; }
    if (action === 'restart') { clearEffects(); hideDialog(); }
    dispatch(action, value);
  }

  function hint() {
    if (!C.isBoardPhase(state)) return;
    if (C.orderReady(state)) {
      $('order').querySelector('.action-button')?.focus({ preventScroll: true });
      tell('上方的订单可以交付了。'); return;
    }
    hintPair = C.nextPair(state);
    hintUntil = presentationTime + 2900;
    if (hintPair) { renderBoard(); tell('这两件可以合成。', 2100); }
    else { board.querySelector('.producer')?.classList.add('hint'); tell('点工作箱，取出一盏小油灯。'); }
  }
  function cancelDrag() {
    if (pointer) {
      try { board.releasePointerCapture(pointer.id); } catch (_) { /* Capture may already have ended. */ }
    }
    pointer = null; $('drag-ghost').hidden = true;
    board.querySelectorAll('.drag-source,.drop-target').forEach(node => node.classList.remove('drag-source', 'drop-target'));
  }
  board.addEventListener('pointerdown', event => {
    if (dialog || !C.isBoardPhase(state) || event.button !== 0) return;
    const target = event.target.closest('[data-cell]');
    if (!target || target.disabled) return;
    const index = Number(target.dataset.cell), value = state.board[index];
    if (!value || value === 'producer' || value === 'locked') return;
    pointer = { id: event.pointerId, index, x: event.clientX, y: event.clientY, dragging: false };
  });
  board.addEventListener('pointermove', event => {
    if (!pointer || event.pointerId !== pointer.id) return;
    if (!pointer.dragging && Math.hypot(event.clientX - pointer.x, event.clientY - pointer.y) > 7) {
      pointer.dragging = true;
      board.setPointerCapture(event.pointerId);
      const ghost = $('drag-ghost'); ghost.innerHTML = itemImage(state.board[pointer.index]); ghost.hidden = false;
      board.querySelector(`[data-cell="${pointer.index}"]`)?.classList.add('drag-source');
    }
    if (!pointer.dragging) return;
    event.preventDefault();
    $('drag-ghost').style.transform = `translate(${event.clientX - 36}px,${event.clientY - 42}px)`;
    board.querySelectorAll('.drop-target').forEach(node => node.classList.remove('drop-target'));
    const target = document.elementFromPoint(event.clientX, event.clientY)?.closest('[data-cell]');
    if (target && !target.disabled && Number(target.dataset.cell) !== pointer.index && state.board[Number(target.dataset.cell)] !== 'producer') target.classList.add('drop-target');
  });
  board.addEventListener('pointerup', event => {
    if (!pointer || event.pointerId !== pointer.id) return;
    const held = pointer;
    const target = document.elementFromPoint(event.clientX, event.clientY)?.closest('[data-cell]');
    cancelDrag();
    if (held.dragging) {
      suppressClickUntil = performance.now() + 350;
      if (target && !target.disabled && state.board[Number(target.dataset.cell)] !== 'producer') perform('drag', { from: held.index, to: Number(target.dataset.cell) });
    }
  });
  board.addEventListener('pointercancel', cancelDrag);
  document.addEventListener('pointerup', event => { if (pointer && !board.contains(event.target)) cancelDrag(); });
  board.addEventListener('lostpointercapture', () => { if (pointer?.dragging) cancelDrag(); });
  board.addEventListener('focusin', event => {
    const cell = event.target.closest('[data-cell]');
    if (!cell) return;
    focusedCell = Number(cell.dataset.cell);
    board.querySelectorAll('[data-cell]').forEach(node => { node.tabIndex = node === cell ? 0 : -1; });
  });
  document.addEventListener('click', event => {
    const button = event.target.closest('button');
    if (!button || button.disabled) return;
    if (button.dataset.cell !== undefined) {
      if (performance.now() < suppressClickUntil) return;
      perform('cell', button.dataset.cell);
    } else if (button.dataset.action) perform(button.dataset.action);
  });
  $('sound-button').addEventListener('click', () => {
    soundEnabled = !soundEnabled;
    try { localStorage.setItem(PREF_KEY, soundEnabled ? 'on' : 'off'); } catch (_) { /* Optional preference. */ }
    renderSound(); if (soundEnabled) { unlockAudio(); sound('supply'); }
  });
  $('help-button').addEventListener('click', () => showDialog('help'));
  $('hint-button').addEventListener('click', hint);
  $('undo-button').addEventListener('click', () => perform('undo'));
  $('overlay').addEventListener('click', event => { if (event.target === $('overlay') && dialog !== 'intro') hideDialog(); });
  document.addEventListener('keydown', event => {
    if (event.key.toLowerCase() === 'f' && !event.ctrlKey && !event.metaKey && !event.altKey && !event.repeat) {
      event.preventDefault();
      if (document.fullscreenElement) document.exitFullscreen?.().catch(() => {});
      else document.documentElement.requestFullscreen?.().catch(() => tell('这个窗口暂时不能进入全屏。'));
      return;
    }
    if (event.key === 'Escape') {
      cancelDrag();
      if (dialog && dialog !== 'intro') hideDialog();
      else if (!dialog) dispatch('clear');
      return;
    }
    if (dialog) {
      if (event.key === 'Tab') {
        const buttons = [...$('overlay').querySelectorAll('button:not(:disabled)')];
        const first = buttons[0], last = buttons[buttons.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
      }
      return;
    }
    const current = document.activeElement?.dataset?.cell;
    if (current === undefined || !C.isBoardPhase(state)) return;
    const offsets = { ArrowUp: -5, ArrowDown: 5, ArrowLeft: -1, ArrowRight: 1 };
    if (!Object.prototype.hasOwnProperty.call(offsets, event.key)) return;
    event.preventDefault();
    const index = Number(current), delta = offsets[event.key];
    let target = index + delta;
    if ((delta === 1 || delta === -1) && Math.floor(target / 5) !== Math.floor(index / 5)) return;
    while (target >= 0 && target < 25) {
      const button = board.querySelector(`[data-cell="${target}"]`);
      if (button && !button.disabled) { button.focus({ preventScroll: true }); break; }
      target += delta;
    }
  });

  function update(dt) {
    presentationTime += dt;
    if (toastUntil && presentationTime >= toastUntil) { $('toast').classList.remove('visible'); toastUntil = 0; }
    if (hintPair && presentationTime >= hintUntil) { hintPair = null; board.querySelectorAll('.hint').forEach(node => node.classList.remove('hint')); }
    if (dialog || !ready) return;
    const oldPhase = state.phase;
    const result = C.step(state, dt);
    state = result.state;
    if (state.phase !== oldPhase) { renderUI(); save(); handleEvent(result.event); }
    else if (isBusy()) updateProgress();
    if (isBusy() && presentationTime - savedAt > 700) { save(); savedAt = presentationTime; }
  }
  function frame(now) {
    const dt = Math.min(100, Math.max(0, now - lastFrame)); lastFrame = now;
    if (now >= manualUntil && !document.hidden) update(dt);
    drawScene();
    requestAnimationFrame(frame);
  }
  window.advanceTime = milliseconds => {
    const duration = Math.max(0, Math.min(120000, Number(milliseconds) || 0));
    const steps = Math.max(1, Math.ceil(duration / (1000 / 60)));
    for (let i = 0; i < steps; i++) update(duration / steps);
    manualUntil = performance.now() + 70; lastFrame = performance.now(); drawScene();
    return window.render_game_to_text();
  };
  window.render_game_to_text = () => JSON.stringify({
    title: '潮灯小镇 · 第一盏归航灯', phase: state.phase, dialog, ready,
    coordinates: 'Board row/column indices start at 0; viewport x grows right, y grows down. Scene art is 900×1600.',
    coins: state.coins, merges: state.merges, selected: state.selected, order: state.phase === 'wood' || state.phase === 'lantern' ? { item: state.phase === 'wood' ? 'w2' : 'l4', have: C.count(state, state.phase === 'wood' ? 'w2' : 'l4'), need: state.phase === 'wood' ? 2 : 1, ready: C.orderReady(state) } : null,
    board: state.board.map((item, index) => {
      const rect = board.querySelector(`[data-cell="${index}"]`)?.getBoundingClientRect();
      return { index, row: Math.floor(index / 5), col: index % 5, item, x: rect ? Math.round(rect.left + rect.width / 2) : null, y: rect ? Math.round(rect.top + rect.height / 2) : null };
    }),
    phaseTime: Math.round(state.phaseTime), duration: C.DURATIONS[state.phase] || 0,
    repairFrame: state.phase === 'repairing' ? repairFrame(state.phaseTime).index : null,
    sceneBeaconVisible: ['lighting', 'beacon', 'arriving', 'reward', 'complete'].includes(state.phase),
    sound: soundEnabled, reducedMotion, assetErrors
  });
  window.Tidekeeper = { getState: () => JSON.parse(C.serialize(state)), getAnimationFrame: () => repairFrame(state.phaseTime), getStaticPosePlacement: staticPosePlacement };
  window.addEventListener('pagehide', save);
  window.addEventListener('beforeunload', save);
  document.addEventListener('visibilitychange', () => { if (document.hidden) { save(); cancelDrag(); } lastFrame = performance.now(); });
  window.addEventListener('blur', cancelDrag);
  window.addEventListener('resize', drawScene);
  window.addEventListener('fullscreenchange', drawScene);
  if (window.ResizeObserver) new ResizeObserver(drawScene).observe($('workbench').previousElementSibling);

  renderSound(); renderUI();
  const files = ['workshop-before-portrait.jpg', 'workshop-after-portrait.jpg', 'workshop-night.jpg', 'character-base.png', 'character-wave.png', 'character-signal.png', 'character-repair.png', 'supply-boat.png', 'neri.png', 'coin.png', ...Object.values(C.ITEMS).map(item => item.image)];
  const extraFrames = animationData()?.frames.map(frameSource).filter(Boolean) || [];
  window.tidekeeperReady = Promise.all([...new Set(files.map(file => ART + file).concat(extraFrames))].map(preload)).then(() => {
    ready = true; drawScene();
    if (state.phase === 'intro') showDialog('intro');
    else if (state.phase === 'complete') showDialog('win');
    else if (reducedMotion && isBusy()) dispatch('finish');
    return true;
  });
  requestAnimationFrame(frame);
})();
