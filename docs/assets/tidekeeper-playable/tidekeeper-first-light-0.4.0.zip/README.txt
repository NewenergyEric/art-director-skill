潮灯小镇 · 第一盏归航灯

候选可玩切片 0.4.0。未经人工主美批准。所有运行素材与字体均在本包内，无 CDN。

解压后，从解压目录运行：
    python -m http.server 4177 --bind 127.0.0.1
然后打开：
    http://127.0.0.1:4177/docs/assets/tidekeeper-playable/play.html

点击或拖动相同物品完成合成；交付木料后修桥，合出四级灯、点灯、接船并领奖。
方向键、回车/空格也可操作；F 全屏。帮助菜单可以重新开始。

保留两个 tidekeeper-* 目录的相邻关系。运行不需安装 JavaScript 依赖。
运行素材字节校验见 runtime-assets.json；字体许可见运行目录 OFL.txt。
动作生成原图与提示词在运行目录 art/source 和 art/generation-record.md。
动作是八张真实姿态图，仍有轻微手指、衣褶与木板漂移；点灯/招呼使用既有静态姿势。
本包不包含旧版完整项目规则包；其冻结哈希和复用素材比对见 baseline-verification.json。
