# 参考说明与反例

项目 `duskwood-watch` / 版本 `0.4.0` / 源状态 `draft`

交付状态：草案交付，尚未经 release 构建。

规范指纹：`f3a9dcbcc15bb89bd56eb4e366ebd5eb3baa2e71bced6a1de1b9bfd2ec802ec7`

由 style-pack.json 派生。修改规范请修改源文件并重建新版本；本手册不是独立审批或第二份规范源。unknown / proposed / planned / candidate 都不等于已确认，未明确参数不得推测为专业定值。

style 决定视觉语言，identity 绑定同一对象，composition 指导布局，context 用于真实尺寸/用途检视；counterexample 仅用于排除，不送入正向图像生成。

批准状态与来源记录不等于工具已检验图像质量或授权人身份。

## DW-NOTES · context · candidate
[打开材料](../references/direction-notes.md)
适用：global
实际看图后的选取、弃用、规则状态与关卡接口。
来源：{"type": "original-study", "source": "2026-10-13用户游戏brief与Agent候选方向；用户参考仅本地观察，不随包分发。"}

## DW-KEEPER · identity · candidate
[打开材料](../references/keeper-base.png)
适用：global
真实生成首件。保留风帽、脸、提灯、弯杖与粗靴；姿势可变。也可供其它类别观察材料处理，不能照抄人物结构。 所有类别可仅参考笔触与材质，不继承角色结构。
来源：{"type": "image-generation", "source": "Built-in image_gen, 2026-10-13. Original study."}

## DW-MAP · composition · candidate
[打开材料](../references/play/assets/v2/map.png)
适用：environment
新1600×1000战场，两路汇合与安静背景。
来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

## DW-KEEPER-WALK · identity · candidate
[打开材料](../references/play/assets/v2/actors/keeper-walk.png)
适用：character, motion
11生成部件，12帧可编辑骨架烘焙；按位移驱动。
来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

## DW-KEEPER-META · context · candidate
[打开材料](../references/play/assets/v2/actors/keeper-animation.json)
适用：character, motion
384×448，anchor(192,404)，displayHeight122，43.5714px/周期。
来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

## DW-BOW · style · candidate
[打开材料](../references/play/assets/v2/weapons/ballista-aim.png)
适用：prop, ui
八向枝弩机件；底座独立，发射状态另件。
来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

## DW-BELL · style · candidate
[打开材料](../references/play/assets/v2/weapons/bell-stand.png)
适用：prop, ui
固定枝架；吊铃另有8姿态动画。
来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

## DW-ENEMY · identity · candidate
[打开材料](../references/play/assets/enemy.png)
适用：character, motion
普通木灵原始身份。
来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

## DW-ENEMY-WALK · identity · candidate
[打开材料](../references/play/assets/enemy-walk.png)
适用：character, motion
8个实绘奔跑姿势。
来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

## DW-ENEMY-META · context · candidate
[打开材料](../references/play/assets/enemy-animation.json)
适用：character, motion
336×256一格，anchor [0.5,0.96875]。
来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

## DW-BRUTE · identity · candidate
[打开材料](../references/play/assets/v2/actors/rootguard-walk.png)
适用：character
根甲卫：木壳、根腿与枝钳；八帧候选动作。
来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

## DW-SHRINE · identity · candidate
[打开材料](../references/play/assets/shrine.png)
适用：prop, environment
道路终点防守灯屋。
来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

## DW-SEED · style · candidate
[打开材料](../references/play/assets/v2/world/lamp-seed-coin.png)
适用：ui, prop
灯籽币；世界资源、真实HUD和行囊共用。
来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

## DW-LIFE · style · candidate
[打开材料](../references/play/assets/life.png)
适用：ui
灯火生命图标。
来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

## DW-ARROW · style · candidate
[打开材料](../references/play/assets/arrow.png)
适用：motion
从塔到敌人的箭矢，朝右为原始轴。
来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

## DW-HIT · style · candidate
[打开材料](../references/play/assets/hit.png)
适用：motion
叶片与碎木命中事件。
来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

## DW-UI-FONT · font · candidate
[打开材料](../references/play/assets/ui.woff2)
适用：ui
Noto Sans SC，OFL子集，数字与操作说明。
来源：{"type": "open-font", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

## DW-SANS-OFL · context · candidate
[打开材料](../references/play/assets/notosanssc-OFL.txt)
适用：ui
随包字体许可。
来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

## DW-LIVE-KEEPER · identity · candidate
[打开材料](../references/play/assets/keeper-base.png)
适用：character, ui
开始页人物立绘，非地图动作。
来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

## DW-RUNTIME-0 · context · candidate
[打开材料](../references/play/index.html)
适用：global
可编辑真实游戏运行源；所有依赖随包。
来源：{"type": "original-code", "source": "本轮Agent团队制作与浏览器实测。"}

## DW-RUNTIME-1 · context · candidate
[打开材料](../references/play/v2.css)
适用：global
V2画布布局及本地Sans字体。
来源：{"type": "original-code", "source": "本轮Agent团队制作与浏览器实测。"}

## DW-RUNTIME-2 · context · candidate
[打开材料](../references/play/game-v2.js)
适用：global
移动提灯、三种武器、四类敌人、真实Canvas操作与动态光雾。
来源：{"type": "original-code", "source": "本轮Agent团队制作与浏览器实测。"}

## DW-RUNTIME-3 · context · candidate
[打开材料](../references/play/game-v2-config.js)
适用：global
可编辑双路径与四夜关卡数据。
来源：{"type": "original-code", "source": "本轮Agent团队制作与浏览器实测。"}

## DW-ASSEMBLY · composition · candidate
[打开材料](../references/assembly-browser.png)
适用：global
实际1600×1000 Chrome V2游戏运行画面；非生图UI。
来源：{"type": "browser-screenshot", "source": "Playwright记录正常1倍速度运行。"}

## DW-PRODUCTION · context · candidate
[打开材料](../references/production-record.md)
适用：global
原始提示词、实际检查、来源缺口与未解决动作问题。
来源：{"type": "production-record", "source": "2026-10-13 本次实际制作记录。"}

## DW-SOURCES · context · candidate
[打开材料](../references/play/SOURCES.md)
适用：global
来源与字体许可；完整原始生成证据在游戏交付目录。
来源：{"type": "production-record", "source": "2026-10-13 本次实际制作记录。"}

## DW-PLAY-README · context · candidate
[打开材料](../references/play/README.md)
适用：global
运行与操作；完整 QA 文件在游戏交付目录。
来源：{"type": "production-record", "source": "2026-10-13 本次实际制作记录。"}

## DW-PLAY-SERVER · context · candidate
[打开材料](../references/play/server.mjs)
适用：global
无依赖本地 HTTP 服务器，默认 5174。
来源：{"type": "production-record", "source": "2026-10-13 本次实际制作记录。"}

## DW-V2-BRIEF · context · candidate
[打开材料](../references/rebuild-brief.md)
适用：global
本轮范围、分工、用途尺度与真实状态职责。
来源：{"type": "user-feedback", "source": "2026-10-13 本轮反馈与Agent制作约定。"}

## DW-V2-B7188853A8 · context · candidate
[打开材料](../references/play/v2.html)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "production-record", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-9959204705 · context · candidate
[打开材料](../references/play/assets/v2/actors/actors-manifest.json)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "production-record", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-96B6CFDAFA · context · candidate
[打开材料](../references/play/assets/v2/actors/keeper-parts/body.png)
适用：global
可编辑keeper绑定部件，烘焙来源。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-80801CDF7B · context · candidate
[打开材料](../references/play/assets/v2/actors/keeper-parts/far-arm.png)
适用：global
可编辑keeper绑定部件，烘焙来源。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-6A723CC0B0 · context · candidate
[打开材料](../references/play/assets/v2/actors/keeper-parts/far-boot.png)
适用：global
可编辑keeper绑定部件，烘焙来源。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-2FB56F51C0 · context · candidate
[打开材料](../references/play/assets/v2/actors/keeper-parts/far-shin.png)
适用：global
可编辑keeper绑定部件，烘焙来源。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-BD5ED6FC54 · context · candidate
[打开材料](../references/play/assets/v2/actors/keeper-parts/far-thigh.png)
适用：global
可编辑keeper绑定部件，烘焙来源。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-C3E5D7303A · context · candidate
[打开材料](../references/play/assets/v2/actors/keeper-parts/lantern.png)
适用：global
可编辑keeper绑定部件，烘焙来源。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-AA158F4061 · context · candidate
[打开材料](../references/play/assets/v2/actors/keeper-parts/near-arm.png)
适用：global
可编辑keeper绑定部件，烘焙来源。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-111C606CF5 · context · candidate
[打开材料](../references/play/assets/v2/actors/keeper-parts/near-boot.png)
适用：global
可编辑keeper绑定部件，烘焙来源。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-A0733CE739 · context · candidate
[打开材料](../references/play/assets/v2/actors/keeper-parts/near-shin.png)
适用：global
可编辑keeper绑定部件，烘焙来源。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-D85DD888D7 · context · candidate
[打开材料](../references/play/assets/v2/actors/keeper-parts/near-thigh.png)
适用：global
可编辑keeper绑定部件，烘焙来源。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-A0E6DFDADA · context · candidate
[打开材料](../references/play/assets/v2/actors/keeper-parts/staff.png)
适用：global
可编辑keeper绑定部件，烘焙来源。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-9D20ED899A · context · candidate
[打开材料](../references/play/assets/v2/actors/keeper-rig.json)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "production-record", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-2676E61AB2 · context · candidate
[打开材料](../references/play/assets/v2/actors/moonmoth-animation.json)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "production-record", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-80E6099946 · context · candidate
[打开材料](../references/play/assets/v2/actors/moonmoth-walk.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-F7303F0708 · context · candidate
[打开材料](../references/play/assets/v2/actors/rootguard-animation.json)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "production-record", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-B84A3309A8 · context · candidate
[打开材料](../references/play/assets/v2/actors/sporepod-animation.json)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "production-record", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-6537CA1293 · context · candidate
[打开材料](../references/play/assets/v2/actors/sporepod-walk.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-2B70CAB002 · context · candidate
[打开材料](../references/play/assets/v2/title.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-5AA1B75049 · context · candidate
[打开材料](../references/play/assets/v2/weapons/ballista-base.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-D6702D9DDB · context · candidate
[打开材料](../references/play/assets/v2/weapons/ballista-release.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-4485B8B3F8 · context · candidate
[打开材料](../references/play/assets/v2/weapons/bell-swing.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-367A534051 · context · candidate
[打开材料](../references/play/assets/v2/weapons/empty-base.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-8E09995802 · context · candidate
[打开材料](../references/play/assets/v2/weapons/empty-stump.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-3456B7BF9C · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/ballista-aim-E.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-A8B4628E4A · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/ballista-aim-N.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-54EF4A4980 · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/ballista-aim-NE.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-53C71D8721 · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/ballista-aim-NW.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-C3A267D49B · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/ballista-aim-S.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-24B8860974 · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/ballista-aim-SE.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-F476F5E677 · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/ballista-aim-SW.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-21CF4A7506 · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/ballista-aim-W.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-D142503AB0 · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/ballista-release-E.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-5BC32E4130 · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/ballista-release-N.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-CECD722391 · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/ballista-release-NE.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-3351E0C8C5 · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/ballista-release-NW.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-433908B64B · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/ballista-release-S.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-F4664189A3 · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/ballista-release-SE.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-975C24A9BB · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/ballista-release-SW.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-77E1C1C429 · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/ballista-release-W.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-EDCD91A387 · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/bell-swing-00.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-8683F7F627 · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/bell-swing-01.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-E67C393B6C · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/bell-swing-02.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-C5AE748F45 · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/bell-swing-03.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-B9CFDB85AD · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/bell-swing-04.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-0D4A65A8B0 · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/bell-swing-05.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-0833FE9CF1 · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/bell-swing-06.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-9453145F50 · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/bell-swing-07.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-A6192EBB23 · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/mortar-aim-E.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-DBF090FE66 · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/mortar-aim-N.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-494563079B · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/mortar-aim-NE.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-6E5ED38F5D · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/mortar-aim-NW.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-03092C1918 · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/mortar-aim-S.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-8E07567C8E · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/mortar-aim-SE.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-E06E4679D8 · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/mortar-aim-SW.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-64EBE2C102 · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/mortar-aim-W.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-EA63785C29 · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/mortar-release-E.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-EB339065B6 · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/mortar-release-N.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-BF2C1A424A · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/mortar-release-NE.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-137EA860E7 · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/mortar-release-NW.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-35ED8AEE7A · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/mortar-release-S.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-C206663534 · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/mortar-release-SE.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-951C818A6F · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/mortar-release-SW.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-ECAD571657 · context · candidate
[打开材料](../references/play/assets/v2/weapons/frames/mortar-release-W.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-A3C845760F · context · candidate
[打开材料](../references/play/assets/v2/weapons/mortar-aim.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-C6B67BA81C · context · candidate
[打开材料](../references/play/assets/v2/weapons/mortar-base.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-8112D4B6A9 · context · candidate
[打开材料](../references/play/assets/v2/weapons/mortar-release.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-5DDB667C53 · context · candidate
[打开材料](../references/play/assets/v2/weapons/pinecone-shell.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-A5677EEE3C · context · candidate
[打开材料](../references/play/assets/v2/weapons/weapons.json)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "production-record", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-44C2EC0E69 · context · candidate
[打开材料](../references/play/assets/v2/world/amber-resin.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-84950F7509 · context · candidate
[打开材料](../references/play/assets/v2/world/branch-bundle.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-EAFFF3E648 · context · candidate
[打开材料](../references/play/assets/v2/world/broken-arch.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-DD54144B33 · context · candidate
[打开材料](../references/play/assets/v2/world/build-wheel.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-24BE9939F5 · context · candidate
[打开材料](../references/play/assets/v2/world/copper-gear.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-64C971E6F3 · context · candidate
[打开材料](../references/play/assets/v2/world/copper-hammer.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-835E5AADDA · context · candidate
[打开材料](../references/play/assets/v2/world/crystal-cluster.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-265A60096F · context · candidate
[打开材料](../references/play/assets/v2/world/foreground-branch.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-CA0E80B604 · context · candidate
[打开材料](../references/play/assets/v2/world/herb-bush.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-A7E4EB8E40 · context · candidate
[打开材料](../references/play/assets/v2/world/herbal-potion.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-03EF5A77B7 · context · candidate
[打开材料](../references/play/assets/v2/world/inventory-tray.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-90DFFE79D7 · context · candidate
[打开材料](../references/play/assets/v2/world/items-atlas.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-1A0F87084B · context · candidate
[打开材料](../references/play/assets/v2/world/items-manifest.json)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "production-record", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-F892C449B2 · context · candidate
[打开材料](../references/play/assets/v2/world/lamp-off.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-6ED7FCBC52 · context · candidate
[打开材料](../references/play/assets/v2/world/lamp-on.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-D4221DBDD6 · context · candidate
[打开材料](../references/play/assets/v2/world/lamp-states.json)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "production-record", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-9FAE7FAF58 · context · candidate
[打开材料](../references/play/assets/v2/world/lamp-states.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-7A2235D9D3 · context · candidate
[打开材料](../references/play/assets/v2/world/moon-crystal.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-3092FA58F8 · context · candidate
[打开材料](../references/play/assets/v2/world/moss-oil.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-DC755694B3 · context · candidate
[打开材料](../references/play/assets/v2/world/moss-rock.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-700F7FAD5B · context · candidate
[打开材料](../references/play/assets/v2/world/mushrooms.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-533F7D2253 · context · candidate
[打开材料](../references/play/assets/v2/world/night-charm.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-5B682767E4 · context · candidate
[打开材料](../references/play/assets/v2/world/pruning-hook.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-FBED2F5A48 · context · candidate
[打开材料](../references/play/assets/v2/world/reeds.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-C7983C8B61 · context · candidate
[打开材料](../references/play/assets/v2/world/resource-plaque.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-C63E1D58B1 · context · candidate
[打开材料](../references/play/assets/v2/world/rune-stone.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-79408B09E9 · context · candidate
[打开材料](../references/play/assets/v2/world/scene-atlas.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-E5644F69B8 · context · candidate
[打开材料](../references/play/assets/v2/world/scene-manifest.json)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "production-record", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-068560D1B0 · context · candidate
[打开材料](../references/play/assets/v2/world/shovel.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-E276EBB3E8 · context · candidate
[打开材料](../references/play/assets/v2/world/signpost.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-99A2FC8373 · context · candidate
[打开材料](../references/play/assets/v2/world/skill-medallion.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-F660AFC355 · context · candidate
[打开材料](../references/play/assets/v2/world/toolbox.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-8535596778 · context · candidate
[打开材料](../references/play/assets/v2/world/ui-atlas.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-1C118BC72C · context · candidate
[打开材料](../references/play/assets/v2/world/ui-manifest.json)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "production-record", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-F49983D5C2 · context · candidate
[打开材料](../references/play/assets/v2/world/woodpile.png)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-FEC8941999 · context · candidate
[打开材料](../references/play/assets/v2/world/world-batch.json)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "production-record", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## DW-V2-8291C5E689 · context · candidate
[打开材料](../references/play/assets/v2/world/world-manifest.json)
适用：global
V2实际运行资源、接口或可编辑源文件。
来源：{"type": "production-record", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}
