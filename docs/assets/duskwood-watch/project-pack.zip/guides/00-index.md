# 资料索引与样板计划

项目 `duskwood-watch` / 版本 `0.4.0` / 源状态 `draft`

交付状态：草案交付，尚未经 release 构建。

规范指纹：`f3a9dcbcc15bb89bd56eb4e366ebd5eb3baa2e71bced6a1de1b9bfd2ec802ec7`

由 style-pack.json 派生。修改规范请修改源文件并重建新版本；本手册不是独立审批或第二份规范源。unknown / proposed / planned / candidate 都不等于已确认，未明确参数不得推测为专业定值。

## 入口与责任

主美建立定位、视觉语言、类别/家族与代表样板，再确认交付和发布；成员接收同一个包，按类别与家族创建任务。

- [项目定位](01-positioning.md)
- [美术与组件规范](02-design-system.md)
- [交付与验收](03-delivery-review.md)
- [参考与反例](04-reference-guide.md)
- [规范源](../style-pack.json)
- [完整规范](../STYLE.md)
- [团队执行入口](../SKILL.md)

## 当前缺口

- 最终人工主美批准尚未发生。
- 守林人部分帧腿身份交换、帽形与杖底仍有小漂移；精英目前单姿势，非多方向动画。
- 本次桌面浏览器单关已测；真手机、正式引擎与长期数值平衡未验收。

## 代表样板计划

样板数量和职责由项目决定；计划或候选不能冒充批准样板。组合样板可覆盖多个家族，仍须分别检查各家族要求。

### keeper-first · 守林人首件 · candidate
用途：作为身份和笔触起点，不充当其它类别制作图
覆盖家族：项目整体
发布前必需：是
材料：DW-KEEPER
验收：
- 缩小仍识别提灯与长鼻
- 姿势后续保持道具附着
审批记录：null

### map-first · 地图与路径 · candidate
用途：实际单关用途验证
覆盖家族：forest-map
发布前必需：是
材料：DW-MAP
验收：
- 目标尺寸和组合中可辨
- 技术、视觉、玩法和人工批准分别记录
审批记录：null

### towers-first · 三类防御设施及八向机械状态 · candidate
用途：实际单关用途验证
覆盖家族：wood-defense
发布前必需：是
材料：DW-BOW, DW-BELL
验收：
- 目标尺寸和组合中可辨
- 技术、视觉、玩法和人工批准分别记录
审批记录：null

### hud-first · 真实玩法组合 · candidate
用途：实际单关用途验证
覆盖家族：watch-hud
发布前必需：是
材料：DW-ASSEMBLY
验收：
- 目标尺寸和组合中可辨
- 技术、视觉、玩法和人工批准分别记录
审批记录：null

### motion-first · 24敌人生成源帧与12主角部件烘焙帧 · candidate
用途：实际单关用途验证
覆盖家族：field-actions
发布前必需：是
材料：DW-KEEPER-WALK, DW-ENEMY-WALK
验收：
- 目标尺寸和组合中可辨
- 技术、视觉、玩法和人工批准分别记录
审批记录：null
