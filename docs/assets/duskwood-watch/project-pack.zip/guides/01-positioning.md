# 项目定位

项目 `duskwood-watch` / 版本 `0.4.0` / 源状态 `draft`

交付状态：草案交付，尚未经 release 构建。

规范指纹：`f3a9dcbcc15bb89bd56eb4e366ebd5eb3baa2e71bced6a1de1b9bfd2ec802ec7`

由 style-pack.json 派生。修改规范请修改源文件并重建新版本；本手册不是独立审批或第二份规范源。unknown / proposed / planned / candidate 都不等于已确认，未明确参数不得推测为专业定值。

从静态拼贴原型重构为光域策略战场：三类武器的朝向和攻击、异构敌人动作、实物化交互与可用资源家族。

## 艺术支柱

- 可读道路与防御决策优先
- 大色块、可见笔触和有性格的剪影
- 暖灯只出现在有叙事功能的位置

## 避免

- 塑料高光与均匀碎细节
- 背景成为展板，资产互相抢戏
- 借用参考人物、Logo或附带文字

## 适用范围

```json
{
  "medium": "2D browser exploration tower-defense playable slice",
  "view": "轻俯视三分之四战场；世界内建造轮盘与紧凑材质化HUD",
  "target_platform": "桌面横屏浏览器；1600×1000逻辑画布，保持比例适配",
  "asset_types": [
    "character",
    "environment",
    "prop",
    "ui",
    "motion"
  ]
}
```

## 使用情境 · proposed

自由巡林与采集、移动提灯破甲、昼建夜守；四夜双路径进攻、三类防御设施、四类敌人、胜负重开。

来源：本轮用户改良方向，主Agent与三名制作agent实施并实测。
