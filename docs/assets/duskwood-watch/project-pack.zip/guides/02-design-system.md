# 美术风格与类别家族规范

项目 `duskwood-watch` / 版本 `0.4.0` / 源状态 `draft`

交付状态：草案交付，尚未经 release 构建。

规范指纹：`f3a9dcbcc15bb89bd56eb4e366ebd5eb3baa2e71bced6a1de1b9bfd2ec802ec7`

由 style-pack.json 派生。修改规范请修改源文件并重建新版本；本手册不是独立审批或第二份规范源。unknown / proposed / planned / candidate 都不等于已确认，未明确参数不得推测为专业定值。

固定规则与开放变量同时保留；候选探索不能自动修改全队基线。规则原文及证据见 [STYLE.md](../STYLE.md)。

## 类别要求

### character
守灯人及四类不同结构与步态的暗林敌人
固定：
- 继承DW-SHAPE、DW-ASSEMBLY及本类别规则
可变化：
- 任务指定的动作、状态或功能
技术约束：
```json
{
  "source_format": "PNG RGBA; source generation retained"
}
```

### environment
两条汇合暮林小路，实体遗迹、采集物、灯台与昼夜光雾
固定：
- 继承DW-SHAPE、DW-ASSEMBLY及本类别规则
可变化：
- 任务指定的动作、状态或功能
技术约束：
```json
{
  "source_format": "PNG RGBA; source generation retained"
}
```

### prop
枝弩、臼炮、暮钟；工具、材料、消耗品和货币家族
固定：
- 继承DW-SHAPE、DW-ASSEMBLY及本类别规则
可变化：
- 任务指定的动作、状态或功能
技术约束：
```json
{
  "source_format": "PNG RGBA; source generation retained"
}
```

### ui
世界内建造，12件真实行囊物资，手刻标题和Sans正文
固定：
- 继承DW-SHAPE、DW-ASSEMBLY及本类别规则
可变化：
- 任务指定的动作、状态或功能
技术约束：
```json
{
  "source_format": "Canvas text + PNG UI skins; editable HTML/CSS/JS",
  "font_roles": {
    "title": "Generated four-character lettering; exact editable text retained",
    "body_and_numbers": "Noto Sans SC, local OFL WOFF2 subset"
  },
  "canvas_px": [
    1600,
    1000
  ]
}
```

### motion
多方向机件/释放状态、摆铃、8帧敌人、12帧部件烘焙及事件效果
固定：
- 继承DW-SHAPE、DW-ASSEMBLY及本类别规则
可变化：
- 任务指定的动作、状态或功能
技术约束：
```json
{
  "source_format": "PNG RGBA; source generation retained"
}
```

## forest-actors · 林间角色 · proposed
类别：character；用途：身份清晰，动作可读
规则：DW-SHAPE, DW-CHAR
参考：DW-KEEPER, DW-ENEMY
固定：
- 大剪影、哑光材料；身份分别绑定实体
可变化：
- 已授权步态与表情
技术约束：
```json
{}
```

## wood-defense · 木制防御设施 · proposed
类别：prop；用途：伤害与减速轮廓分工
规则：DW-SHAPE, DW-TOWERS
参考：DW-BOW, DW-BELL
固定：
- 同机位、木材/黄铜、接地
可变化：
- 八向枝弩/臼炮与独立摆铃，各自保留固定基座
技术约束：
```json
{}
```

## forest-map · 暮林道路 · proposed
类别：environment；用途：可读路线与建塔安全地带
规则：DW-SHAPE, DW-MAP
参考：DW-MAP
固定：
- 无天空、轻俯视、道路明暗分离
可变化：
- 关卡路线与植被分区
技术约束：
```json
{}
```

## watch-hud · 守夜界面 · proposed
类别：ui；用途：真实数值和可用状态
规则：DW-UI, DW-ASSEMBLY
参考：DW-UI-FONT, DW-SEED, DW-LIFE, DW-ASSEMBLY
固定：
- 字体角色分工、克制层级、真实可编辑文字
可变化：
- 波次、资源、禁用和选择状态
技术约束：
```json
{}
```

## field-actions · 角色动作与战斗反馈 · proposed
类别：motion；用途：与真实位移和接触点一致
规则：DW-ACTION, DW-FX
参考：DW-KEEPER-WALK, DW-KEEPER-META, DW-ENEMY-WALK, DW-ENEMY-META, DW-ARROW, DW-HIT
固定：
- 同家族统一倍率/根锚点；灯与杖随父链；暂停与减速反映在动作时钟；keeper按位移推进
可变化：
- 步态、触发事件与节奏
技术约束：
```json
{}
```

## field-supplies · 守夜工具与材料 · proposed
类别：prop；用途：采集、升级、补油与技能的实体来源
规则：DW-SHAPE, DW-SUPPLIES
参考：DW-V2-BRIEF, DW-SEED
固定：
- 同视角/光源/轮廓层级；32–48px可读
可变化：
- 工具、材料、货币和消耗品的结构与语义色
技术约束：
```json
{
  "game_canvas_px": [
    1600,
    1000
  ]
}
```
