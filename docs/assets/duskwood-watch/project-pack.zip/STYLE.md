# 暮林守望 · 项目美术规范

项目：`duskwood-watch` · 版本：`0.4.0` · 状态：`draft`
交付状态：草案交付 / 尚未经过 release 构建
内容指纹：`f3a9dcbcc15bb89bd56eb4e366ebd5eb3baa2e71bced6a1de1b9bfd2ec802ec7`

本文件由 style-pack.json 生成。修改源 JSON 后在未发布的工作副本中重新 render；不能把本文件的改写当作规范变更或总监批准。

## 意图

从静态拼贴原型重构为光域策略战场：三类武器的朝向和攻击、异构敌人动作、实物化交互与可用资源家族。

- 可读道路与防御决策优先
- 大色块、可见笔触和有性格的剪影
- 暖灯只出现在有叙事功能的位置

### 避免

- 塑料高光与均匀碎细节
- 背景成为展板，资产互相抢戏
- 借用参考人物、Logo或附带文字

## 适用范围

```json
{
  "medium": "2D browser exploration tower-defense playable slice",
  "view": "轻俯视三分之四战场；世界内建造轮盘与紧凑材质化HUD",
  "target_platform": "桌面横屏浏览器；1600×1000逻辑画布，保持比例适配",
  "asset_types": [
    "character",
    "environment",
    "prop",
    "ui",
    "motion"
  ]
}
```

## 色彩与字体

```json
{
  "colors": {
    "ink": "#172e36",
    "forest": "#27464b",
    "teal": "#507375",
    "ochre": "#be8a49",
    "cream": "#e8d4aa",
    "ember": "#eaa552"
  },
  "fonts": {
    "title": {
      "family": "Noto Serif SC",
      "fallback": [
        "serif"
      ]
    },
    "ui": {
      "family": "Noto Sans SC",
      "fallback": [
        "sans-serif"
      ]
    }
  }
}
```

## 规则

### DW-SHAPE · must · proposed

适用：global

轻俯视三分之四的手绘森林，背景内部笔触和对比收敛；交互物靠清楚外轮廓、功能大形、局部暖赭/哑光铜与月青点缀从背景分离。

原因：在小尺寸仍辨识角色与设施。

允许变化：

- 按本任务槽位变化，保持其余共性。

依据：DW-NOTES
检查方式：visual

### DW-CHAR · must · proposed

适用：character

地图角色使用有性格的大剪影与完整露出的脚/道具；角色各自身份读取实体，不把守林人的头身与配件套给木灵。

原因：身份来自结构而不是一套重复配色。

允许变化：

- 按本任务槽位变化，保持其余共性。

依据：DW-NOTES
检查方式：visual

### DW-MAP · must · proposed

适用：environment

俯视三分之四无地平线；清晰宽土路蜿蜒从左向右，路旁保留建塔空地，深冷树林只围边与分区。

原因：道路、投射物与小人可读。

允许变化：

- 按本任务槽位变化，保持其余共性。

依据：DW-NOTES
检查方式：visual

### DW-TOWERS · must · proposed

适用：prop

弩塔为低矮宽肩树桩与大横弩，直线单体攻击；荆棘铃为细高拱枝、黄铜吊铃与红果，范围减速。两塔无需文字也可辨剪影。

原因：差异承载真实功能。

允许变化：

- 按本任务槽位变化，保持其余共性。

依据：DW-NOTES
检查方式：visual

### DW-UI · must · proposed

适用：ui

主战场铺满画面，资源少量占角；建塔在真实地面基座旁弹出径向选择，背包呈现实物工具材料，反馈随世界对象发生。避开固定底栏、网页卡片、大片说明文字；文字独立编辑。

原因：UI保持绘本气质并让操作有层级。

允许变化：

- 按本任务槽位变化，保持其余共性。

依据：DW-NOTES
检查方式：visual

### DW-ACTION · must · proposed

适用：motion

动作设计先有行为状态/朝向/节奏矩阵，再确定帧数；武器瞄准目标并有蓄力-释放-恢复，角色真实换脚/压缩/展翅，世界速度与动作匹配。静态旋转整座塔或哈希不同不能冒充完整动画。

原因：动作要被看见并可追溯。

允许变化：

- 按本任务槽位变化，保持其余共性。

依据：DW-NOTES
检查方式：visual

### DW-ASSEMBLY · must · proposed

适用：global

在实际游戏尺寸检查相互遮挡、脚底、基座、透明边缘与文字。亮度与细节依用途收敛；单图与整板不能代替实机。

原因：组合是验收的一部分。

允许变化：

- 按本任务槽位变化，保持其余共性。

依据：DW-NOTES
检查方式：visual

### DW-FX · must · proposed

适用：motion

只有攻击、受击、收集、揭雾时出现反馈；投射物从弩口到命中点，减速范围短促苔绿，击中效果不盖角色。

原因：效果解释玩法而不是无原因飘动。

允许变化：

- 按本任务槽位变化，保持其余共性。

依据：DW-NOTES
检查方式：visual

### DW-KEEPER-ID · must · proposed

适用：character

芦婆婆：长鼻、灰发、弯尖赭黄帽、深冷斗篷、粗靴；一手灯、一手弯杖。行走和待机来自同一套裁切与根锚点。

原因：跨姿势身份与停走尺度稳定。

允许变化：

- 按本任务槽位变化，保持其余共性。

依据：DW-NOTES
检查方式：visual

### DW-ENEMY-ID · must · proposed

适用：character

普通木灵：矮胖原木野猪，枝角、钝鼻、苔背、四短腿；木甲精英使用更宽木甲与灰苔，不只是放大普通敌人。

原因：战场职责用结构差异表达。

允许变化：

- 按本任务槽位变化，保持其余共性。

依据：DW-NOTES
检查方式：visual

### DW-SUPPLIES · must · proposed

适用：prop, ui

工具、材料、消耗品和货币属于同一木铜月光材料体系，但剪影与用途可区分：锤头/钩/铲、捆材/矿石/树脂、油瓶/药剂/符、灯籽币/月晶。不用换色充数；每件在世界或真实操作中有用途。

原因：用功能关联与跨类别使用证明资产体量和一致性。

允许变化：

- 具体功能结构和少量语义色。

依据：DW-V2-BRIEF
检查方式：visual

### DW-TYPOGRAPHY · must · proposed

适用：ui

标题使用暮林守望四字手刻宽笔画美术字；数字、操作和说明使用本地Noto Sans SC。V2不用宋体/明体或书卷体作为默认UI。可变文本保持可编辑，32–48px图标旁小字在1600×1000及1280×800实测。

原因：字形与木铜手绘世界一致，同时保证操作阅读。

允许变化：

- 字号、字重随信息角色变化；新语言需另做字形覆盖。

依据：DW-V2-BRIEF
检查方式：visual

## 参考资产

style 控制画风；identity 控制同一对象身份；composition 控制构图；material 控制材质；context 检查实际场景与尺寸；counterexample 仅说明应避免的结果；font 提供字体依据。候选参考不可冒充已批准参考。

- `DW-NOTES` · context · candidate · `references/direction-notes.md`
  适用：global；说明：实际看图后的选取、弃用、规则状态与关卡接口。
  来源：{"type": "original-study", "source": "2026-10-13用户游戏brief与Agent候选方向；用户参考仅本地观察，不随包分发。"}

- `DW-KEEPER` · identity · candidate · `references/keeper-base.png`
  适用：global；说明：真实生成首件。保留风帽、脸、提灯、弯杖与粗靴；姿势可变。也可供其它类别观察材料处理，不能照抄人物结构。 所有类别可仅参考笔触与材质，不继承角色结构。
  来源：{"type": "image-generation", "source": "Built-in image_gen, 2026-10-13. Original study."}

- `DW-MAP` · composition · candidate · `references/play/assets/v2/map.png`
  适用：environment；说明：新1600×1000战场，两路汇合与安静背景。
  来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

- `DW-KEEPER-WALK` · identity · candidate · `references/play/assets/v2/actors/keeper-walk.png`
  适用：character, motion；说明：11生成部件，12帧可编辑骨架烘焙；按位移驱动。
  来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

- `DW-KEEPER-META` · context · candidate · `references/play/assets/v2/actors/keeper-animation.json`
  适用：character, motion；说明：384×448，anchor(192,404)，displayHeight122，43.5714px/周期。
  来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

- `DW-BOW` · style · candidate · `references/play/assets/v2/weapons/ballista-aim.png`
  适用：prop, ui；说明：八向枝弩机件；底座独立，发射状态另件。
  来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

- `DW-BELL` · style · candidate · `references/play/assets/v2/weapons/bell-stand.png`
  适用：prop, ui；说明：固定枝架；吊铃另有8姿态动画。
  来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

- `DW-ENEMY` · identity · candidate · `references/play/assets/enemy.png`
  适用：character, motion；说明：普通木灵原始身份。
  来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

- `DW-ENEMY-WALK` · identity · candidate · `references/play/assets/enemy-walk.png`
  适用：character, motion；说明：8个实绘奔跑姿势。
  来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

- `DW-ENEMY-META` · context · candidate · `references/play/assets/enemy-animation.json`
  适用：character, motion；说明：336×256一格，anchor [0.5,0.96875]。
  来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

- `DW-BRUTE` · identity · candidate · `references/play/assets/v2/actors/rootguard-walk.png`
  适用：character；说明：根甲卫：木壳、根腿与枝钳；八帧候选动作。
  来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

- `DW-SHRINE` · identity · candidate · `references/play/assets/shrine.png`
  适用：prop, environment；说明：道路终点防守灯屋。
  来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

- `DW-SEED` · style · candidate · `references/play/assets/v2/world/lamp-seed-coin.png`
  适用：ui, prop；说明：灯籽币；世界资源、真实HUD和行囊共用。
  来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

- `DW-LIFE` · style · candidate · `references/play/assets/life.png`
  适用：ui；说明：灯火生命图标。
  来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

- `DW-ARROW` · style · candidate · `references/play/assets/arrow.png`
  适用：motion；说明：从塔到敌人的箭矢，朝右为原始轴。
  来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

- `DW-HIT` · style · candidate · `references/play/assets/hit.png`
  适用：motion；说明：叶片与碎木命中事件。
  来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

- `DW-UI-FONT` · font · candidate · `references/play/assets/ui.woff2`
  适用：ui；说明：Noto Sans SC，OFL子集，数字与操作说明。
  来源：{"type": "open-font", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

- `DW-SANS-OFL` · context · candidate · `references/play/assets/notosanssc-OFL.txt`
  适用：ui；说明：随包字体许可。
  来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

- `DW-LIVE-KEEPER` · identity · candidate · `references/play/assets/keeper-base.png`
  适用：character, ui；说明：开始页人物立绘，非地图动作。
  来源：{"type": "original-study", "source": "本次真实生成、确定性导出或原生实现；见游戏SOURCES.md与evidence。"}

- `DW-RUNTIME-0` · context · candidate · `references/play/index.html`
  适用：global；说明：可编辑真实游戏运行源；所有依赖随包。
  来源：{"type": "original-code", "source": "本轮Agent团队制作与浏览器实测。"}

- `DW-RUNTIME-1` · context · candidate · `references/play/v2.css`
  适用：global；说明：V2画布布局及本地Sans字体。
  来源：{"type": "original-code", "source": "本轮Agent团队制作与浏览器实测。"}

- `DW-RUNTIME-2` · context · candidate · `references/play/game-v2.js`
  适用：global；说明：移动提灯、三种武器、四类敌人、真实Canvas操作与动态光雾。
  来源：{"type": "original-code", "source": "本轮Agent团队制作与浏览器实测。"}

- `DW-RUNTIME-3` · context · candidate · `references/play/game-v2-config.js`
  适用：global；说明：可编辑双路径与四夜关卡数据。
  来源：{"type": "original-code", "source": "本轮Agent团队制作与浏览器实测。"}

- `DW-ASSEMBLY` · composition · candidate · `references/assembly-browser.png`
  适用：global；说明：实际1600×1000 Chrome V2游戏运行画面；非生图UI。
  来源：{"type": "browser-screenshot", "source": "Playwright记录正常1倍速度运行。"}

- `DW-PRODUCTION` · context · candidate · `references/production-record.md`
  适用：global；说明：原始提示词、实际检查、来源缺口与未解决动作问题。
  来源：{"type": "production-record", "source": "2026-10-13 本次实际制作记录。"}

- `DW-SOURCES` · context · candidate · `references/play/SOURCES.md`
  适用：global；说明：来源与字体许可；完整原始生成证据在游戏交付目录。
  来源：{"type": "production-record", "source": "2026-10-13 本次实际制作记录。"}

- `DW-PLAY-README` · context · candidate · `references/play/README.md`
  适用：global；说明：运行与操作；完整 QA 文件在游戏交付目录。
  来源：{"type": "production-record", "source": "2026-10-13 本次实际制作记录。"}

- `DW-PLAY-SERVER` · context · candidate · `references/play/server.mjs`
  适用：global；说明：无依赖本地 HTTP 服务器，默认 5174。
  来源：{"type": "production-record", "source": "2026-10-13 本次实际制作记录。"}

- `DW-V2-BRIEF` · context · candidate · `references/rebuild-brief.md`
  适用：global；说明：本轮范围、分工、用途尺度与真实状态职责。
  来源：{"type": "user-feedback", "source": "2026-10-13 本轮反馈与Agent制作约定。"}

- `DW-V2-B7188853A8` · context · candidate · `references/play/v2.html`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "production-record", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-9959204705` · context · candidate · `references/play/assets/v2/actors/actors-manifest.json`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "production-record", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-96B6CFDAFA` · context · candidate · `references/play/assets/v2/actors/keeper-parts/body.png`
  适用：global；说明：可编辑keeper绑定部件，烘焙来源。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-80801CDF7B` · context · candidate · `references/play/assets/v2/actors/keeper-parts/far-arm.png`
  适用：global；说明：可编辑keeper绑定部件，烘焙来源。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-6A723CC0B0` · context · candidate · `references/play/assets/v2/actors/keeper-parts/far-boot.png`
  适用：global；说明：可编辑keeper绑定部件，烘焙来源。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-2FB56F51C0` · context · candidate · `references/play/assets/v2/actors/keeper-parts/far-shin.png`
  适用：global；说明：可编辑keeper绑定部件，烘焙来源。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-BD5ED6FC54` · context · candidate · `references/play/assets/v2/actors/keeper-parts/far-thigh.png`
  适用：global；说明：可编辑keeper绑定部件，烘焙来源。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-C3E5D7303A` · context · candidate · `references/play/assets/v2/actors/keeper-parts/lantern.png`
  适用：global；说明：可编辑keeper绑定部件，烘焙来源。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-AA158F4061` · context · candidate · `references/play/assets/v2/actors/keeper-parts/near-arm.png`
  适用：global；说明：可编辑keeper绑定部件，烘焙来源。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-111C606CF5` · context · candidate · `references/play/assets/v2/actors/keeper-parts/near-boot.png`
  适用：global；说明：可编辑keeper绑定部件，烘焙来源。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-A0733CE739` · context · candidate · `references/play/assets/v2/actors/keeper-parts/near-shin.png`
  适用：global；说明：可编辑keeper绑定部件，烘焙来源。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-D85DD888D7` · context · candidate · `references/play/assets/v2/actors/keeper-parts/near-thigh.png`
  适用：global；说明：可编辑keeper绑定部件，烘焙来源。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-A0E6DFDADA` · context · candidate · `references/play/assets/v2/actors/keeper-parts/staff.png`
  适用：global；说明：可编辑keeper绑定部件，烘焙来源。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-9D20ED899A` · context · candidate · `references/play/assets/v2/actors/keeper-rig.json`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "production-record", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-2676E61AB2` · context · candidate · `references/play/assets/v2/actors/moonmoth-animation.json`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "production-record", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-80E6099946` · context · candidate · `references/play/assets/v2/actors/moonmoth-walk.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-F7303F0708` · context · candidate · `references/play/assets/v2/actors/rootguard-animation.json`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "production-record", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-B84A3309A8` · context · candidate · `references/play/assets/v2/actors/sporepod-animation.json`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "production-record", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-6537CA1293` · context · candidate · `references/play/assets/v2/actors/sporepod-walk.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-2B70CAB002` · context · candidate · `references/play/assets/v2/title.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-5AA1B75049` · context · candidate · `references/play/assets/v2/weapons/ballista-base.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-D6702D9DDB` · context · candidate · `references/play/assets/v2/weapons/ballista-release.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-4485B8B3F8` · context · candidate · `references/play/assets/v2/weapons/bell-swing.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-367A534051` · context · candidate · `references/play/assets/v2/weapons/empty-base.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-8E09995802` · context · candidate · `references/play/assets/v2/weapons/empty-stump.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-3456B7BF9C` · context · candidate · `references/play/assets/v2/weapons/frames/ballista-aim-E.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-A8B4628E4A` · context · candidate · `references/play/assets/v2/weapons/frames/ballista-aim-N.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-54EF4A4980` · context · candidate · `references/play/assets/v2/weapons/frames/ballista-aim-NE.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-53C71D8721` · context · candidate · `references/play/assets/v2/weapons/frames/ballista-aim-NW.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-C3A267D49B` · context · candidate · `references/play/assets/v2/weapons/frames/ballista-aim-S.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-24B8860974` · context · candidate · `references/play/assets/v2/weapons/frames/ballista-aim-SE.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-F476F5E677` · context · candidate · `references/play/assets/v2/weapons/frames/ballista-aim-SW.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-21CF4A7506` · context · candidate · `references/play/assets/v2/weapons/frames/ballista-aim-W.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-D142503AB0` · context · candidate · `references/play/assets/v2/weapons/frames/ballista-release-E.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-5BC32E4130` · context · candidate · `references/play/assets/v2/weapons/frames/ballista-release-N.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-CECD722391` · context · candidate · `references/play/assets/v2/weapons/frames/ballista-release-NE.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-3351E0C8C5` · context · candidate · `references/play/assets/v2/weapons/frames/ballista-release-NW.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-433908B64B` · context · candidate · `references/play/assets/v2/weapons/frames/ballista-release-S.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-F4664189A3` · context · candidate · `references/play/assets/v2/weapons/frames/ballista-release-SE.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-975C24A9BB` · context · candidate · `references/play/assets/v2/weapons/frames/ballista-release-SW.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-77E1C1C429` · context · candidate · `references/play/assets/v2/weapons/frames/ballista-release-W.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-EDCD91A387` · context · candidate · `references/play/assets/v2/weapons/frames/bell-swing-00.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-8683F7F627` · context · candidate · `references/play/assets/v2/weapons/frames/bell-swing-01.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-E67C393B6C` · context · candidate · `references/play/assets/v2/weapons/frames/bell-swing-02.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-C5AE748F45` · context · candidate · `references/play/assets/v2/weapons/frames/bell-swing-03.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-B9CFDB85AD` · context · candidate · `references/play/assets/v2/weapons/frames/bell-swing-04.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-0D4A65A8B0` · context · candidate · `references/play/assets/v2/weapons/frames/bell-swing-05.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-0833FE9CF1` · context · candidate · `references/play/assets/v2/weapons/frames/bell-swing-06.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-9453145F50` · context · candidate · `references/play/assets/v2/weapons/frames/bell-swing-07.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-A6192EBB23` · context · candidate · `references/play/assets/v2/weapons/frames/mortar-aim-E.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-DBF090FE66` · context · candidate · `references/play/assets/v2/weapons/frames/mortar-aim-N.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-494563079B` · context · candidate · `references/play/assets/v2/weapons/frames/mortar-aim-NE.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-6E5ED38F5D` · context · candidate · `references/play/assets/v2/weapons/frames/mortar-aim-NW.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-03092C1918` · context · candidate · `references/play/assets/v2/weapons/frames/mortar-aim-S.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-8E07567C8E` · context · candidate · `references/play/assets/v2/weapons/frames/mortar-aim-SE.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-E06E4679D8` · context · candidate · `references/play/assets/v2/weapons/frames/mortar-aim-SW.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-64EBE2C102` · context · candidate · `references/play/assets/v2/weapons/frames/mortar-aim-W.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-EA63785C29` · context · candidate · `references/play/assets/v2/weapons/frames/mortar-release-E.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-EB339065B6` · context · candidate · `references/play/assets/v2/weapons/frames/mortar-release-N.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-BF2C1A424A` · context · candidate · `references/play/assets/v2/weapons/frames/mortar-release-NE.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-137EA860E7` · context · candidate · `references/play/assets/v2/weapons/frames/mortar-release-NW.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-35ED8AEE7A` · context · candidate · `references/play/assets/v2/weapons/frames/mortar-release-S.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-C206663534` · context · candidate · `references/play/assets/v2/weapons/frames/mortar-release-SE.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-951C818A6F` · context · candidate · `references/play/assets/v2/weapons/frames/mortar-release-SW.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-ECAD571657` · context · candidate · `references/play/assets/v2/weapons/frames/mortar-release-W.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-A3C845760F` · context · candidate · `references/play/assets/v2/weapons/mortar-aim.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-C6B67BA81C` · context · candidate · `references/play/assets/v2/weapons/mortar-base.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-8112D4B6A9` · context · candidate · `references/play/assets/v2/weapons/mortar-release.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-5DDB667C53` · context · candidate · `references/play/assets/v2/weapons/pinecone-shell.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-A5677EEE3C` · context · candidate · `references/play/assets/v2/weapons/weapons.json`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "production-record", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-44C2EC0E69` · context · candidate · `references/play/assets/v2/world/amber-resin.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-84950F7509` · context · candidate · `references/play/assets/v2/world/branch-bundle.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-EAFFF3E648` · context · candidate · `references/play/assets/v2/world/broken-arch.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-DD54144B33` · context · candidate · `references/play/assets/v2/world/build-wheel.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-24BE9939F5` · context · candidate · `references/play/assets/v2/world/copper-gear.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-64C971E6F3` · context · candidate · `references/play/assets/v2/world/copper-hammer.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-835E5AADDA` · context · candidate · `references/play/assets/v2/world/crystal-cluster.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-265A60096F` · context · candidate · `references/play/assets/v2/world/foreground-branch.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-CA0E80B604` · context · candidate · `references/play/assets/v2/world/herb-bush.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-A7E4EB8E40` · context · candidate · `references/play/assets/v2/world/herbal-potion.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-03EF5A77B7` · context · candidate · `references/play/assets/v2/world/inventory-tray.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-90DFFE79D7` · context · candidate · `references/play/assets/v2/world/items-atlas.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-1A0F87084B` · context · candidate · `references/play/assets/v2/world/items-manifest.json`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "production-record", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-F892C449B2` · context · candidate · `references/play/assets/v2/world/lamp-off.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-6ED7FCBC52` · context · candidate · `references/play/assets/v2/world/lamp-on.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-D4221DBDD6` · context · candidate · `references/play/assets/v2/world/lamp-states.json`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "production-record", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-9FAE7FAF58` · context · candidate · `references/play/assets/v2/world/lamp-states.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-7A2235D9D3` · context · candidate · `references/play/assets/v2/world/moon-crystal.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-3092FA58F8` · context · candidate · `references/play/assets/v2/world/moss-oil.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-DC755694B3` · context · candidate · `references/play/assets/v2/world/moss-rock.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-700F7FAD5B` · context · candidate · `references/play/assets/v2/world/mushrooms.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-533F7D2253` · context · candidate · `references/play/assets/v2/world/night-charm.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-5B682767E4` · context · candidate · `references/play/assets/v2/world/pruning-hook.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-FBED2F5A48` · context · candidate · `references/play/assets/v2/world/reeds.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-C7983C8B61` · context · candidate · `references/play/assets/v2/world/resource-plaque.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-C63E1D58B1` · context · candidate · `references/play/assets/v2/world/rune-stone.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-79408B09E9` · context · candidate · `references/play/assets/v2/world/scene-atlas.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-E5644F69B8` · context · candidate · `references/play/assets/v2/world/scene-manifest.json`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "production-record", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-068560D1B0` · context · candidate · `references/play/assets/v2/world/shovel.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-E276EBB3E8` · context · candidate · `references/play/assets/v2/world/signpost.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-99A2FC8373` · context · candidate · `references/play/assets/v2/world/skill-medallion.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-F660AFC355` · context · candidate · `references/play/assets/v2/world/toolbox.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-8535596778` · context · candidate · `references/play/assets/v2/world/ui-atlas.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-1C118BC72C` · context · candidate · `references/play/assets/v2/world/ui-manifest.json`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "production-record", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-F49983D5C2` · context · candidate · `references/play/assets/v2/world/woodpile.png`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "original-study", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-FEC8941999` · context · candidate · `references/play/assets/v2/world/world-batch.json`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "production-record", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

- `DW-V2-8291C5E689` · context · candidate · `references/play/assets/v2/world/world-manifest.json`
  适用：global；说明：V2实际运行资源、接口或可编辑源文件。
  来源：{"type": "production-record", "source": "三名制作agent与主工程实际交付；见完整案例evidence/v2。"}

## character

守灯人及四类不同结构与步态的暗林敌人

固定约束：

- 继承DW-SHAPE、DW-ASSEMBLY及本类别规则

可变范围：

- 任务指定的动作、状态或功能

技术规格（仅作为项目要求，CLI 不对生成资产自动检测这些项目）：

```json
{
  "source_format": "PNG RGBA; source generation retained"
}
```

## environment

两条汇合暮林小路，实体遗迹、采集物、灯台与昼夜光雾

固定约束：

- 继承DW-SHAPE、DW-ASSEMBLY及本类别规则

可变范围：

- 任务指定的动作、状态或功能

技术规格（仅作为项目要求，CLI 不对生成资产自动检测这些项目）：

```json
{
  "source_format": "PNG RGBA; source generation retained"
}
```

## prop

枝弩、臼炮、暮钟；工具、材料、消耗品和货币家族

固定约束：

- 继承DW-SHAPE、DW-ASSEMBLY及本类别规则

可变范围：

- 任务指定的动作、状态或功能

技术规格（仅作为项目要求，CLI 不对生成资产自动检测这些项目）：

```json
{
  "source_format": "PNG RGBA; source generation retained"
}
```

## ui

世界内建造，12件真实行囊物资，手刻标题和Sans正文

固定约束：

- 继承DW-SHAPE、DW-ASSEMBLY及本类别规则

可变范围：

- 任务指定的动作、状态或功能

技术规格（仅作为项目要求，CLI 不对生成资产自动检测这些项目）：

```json
{
  "source_format": "Canvas text + PNG UI skins; editable HTML/CSS/JS",
  "font_roles": {
    "title": "Generated four-character lettering; exact editable text retained",
    "body_and_numbers": "Noto Sans SC, local OFL WOFF2 subset"
  },
  "canvas_px": [
    1600,
    1000
  ]
}
```

## motion

多方向机件/释放状态、摆铃、8帧敌人、12帧部件烘焙及事件效果

固定约束：

- 继承DW-SHAPE、DW-ASSEMBLY及本类别规则

可变范围：

- 任务指定的动作、状态或功能

技术规格（仅作为项目要求，CLI 不对生成资产自动检测这些项目）：

```json
{
  "source_format": "PNG RGBA; source generation retained"
}
```

## 实体身份

```json
[
  {
    "id": "keeper",
    "kind": "character",
    "aliases": [
      "守林人",
      "芦婆婆"
    ],
    "identity_rules": [
      "DW-KEEPER-ID"
    ],
    "reference_ids": [
      "DW-KEEPER"
    ],
    "fixed_features": [
      "弯尖赭黄风帽、长鼻、深冷斗篷、粗靴、右手灯与左手弯杖"
    ],
    "variations": [
      "步态、表情"
    ]
  },
  {
    "id": "woodling",
    "kind": "character",
    "aliases": [
      "木灵",
      "苔背野猪"
    ],
    "identity_rules": [
      "DW-ENEMY-ID"
    ],
    "reference_ids": [
      "DW-ENEMY",
      "DW-ENEMY-WALK"
    ],
    "fixed_features": [
      "木鼻、枝角、苔背、四足"
    ],
    "variations": [
      "步态",
      "精英结构变体需要单独身份图"
    ]
  }
]
```

## 制作配方

```json
[]
```

## 决策记录

```json
[
  {
    "id": "DW-DIR-01",
    "decision": "只选择深冷森林与暖灯、夸张绘本轮廓；不混入参考中的3D餐桌渲染或高饱和龙主题。",
    "rationale": "多图参考需要选择明确语法，避免风格拼盘。",
    "status": "proposed",
    "source": "实际观察用户附件；本选择为Agent候选，未声称主美批准。"
  },
  {
    "id": "DW-INTEGRATION-02",
    "decision": "根据实际组合使用同一动作表待机帧，修正停走尺度跳变；加入木灵8帧与结构不同的木甲精英。",
    "rationale": "用户再次强调多帧动态与资产体量；实机看图发现待机裁切不一致。",
    "status": "proposed",
    "source": "2026-10-13用户追加要求与实际Chrome组合检查。"
  },
  {
    "id": "DW-REVISION-03",
    "decision": "用户明确要求扩大真实资产家族、解决武器转向和动作，重构PPT式布局并让点灯影响攻防。",
    "rationale": "V1只达到单关可运行，未证明生产体量和动态一致性；授权据此制作新版候选。",
    "status": "accepted",
    "source": "2026-10-13 用户本轮直接反馈与具体玩法建议。"
  },
  {
    "id": "DW-TECH-031",
    "decision": "修正遗留1200×800技术字段为本轮1600×1000，补守夜物品家族。",
    "rationale": "world成员开工时发现旧字段与新任务brief不同；生成已按新brief执行，视觉语言不变，无需重生。",
    "status": "accepted",
    "source": "2026-10-13团队校对记录；主Agent按用户范围落实。"
  },
  {
    "id": "DW-INTEGRATION-04",
    "decision": "将本轮三名制作agent交付的兼容0.3.1候选资产整合为0.4.0；字体采用手刻标题与Sans真实界面文字。",
    "rationale": "落实用户资产体量、动画、游戏空间与字体反馈；不把自查写成人工批准。",
    "status": "accepted",
    "source": "2026-10-13用户反馈与2026-10-14实际恢复/集成/浏览器记录。"
  }
]
```

## 待决问题

- 最终人工主美批准尚未发生。
- 守林人部分帧腿身份交换、帽形与杖底仍有小漂移；精英目前单姿势，非多方向动画。
- 本次桌面浏览器单关已测；真手机、正式引擎与长期数值平衡未验收。

## 审批记录

```json
null
```

审批字段及证据文件只证明存在该记录；本工具不验证审批者身份、授权、资产权利或美术质量。
