# 项目定位

项目 `tidekeeper` / 版本 `0.2.0` / 源状态 `draft`

交付状态：草案交付，尚未经 release 构建。

规范指纹：`9f24ba82a726248c5d26f9f8c17f218f4c96a29d4fcb4cbef1a83b7283e3cb63`

由 style-pack.json 派生。修改规范请修改源文件并重建新版本；本手册不是独立审批或第二份规范源。unknown / proposed / planned / candidate 都不等于已确认，未明确参数不得推测为专业定值。

同一份视觉记忆：主美先立样板和类别要求，成员拿包续作阿澜、灯房、订单界面和L3/L4合成灯具。

## 艺术支柱

- 像休闲合成游戏，先服务格内识别与操作
- 保留海港修复的共同形状与色彩语言
- 身份、类别、单次变化分开，组合时检验

## 避免

- 把宣传插画当游戏画面标准
- 让写实金属噪点淹没小格轮廓
- 只统一配色而不统一结构、镜头和状态

## 适用范围

```json
{
  "medium": "2D casual mobile merge-game art and editable UI study",
  "view": "角色对话立绘 / 俯视三分之四地图 / 轻俯视棋子 / 平面UI，各自有样板",
  "target_platform": "390×844 浏览器试作；真实手机与引擎待测",
  "asset_types": [
    "character",
    "environment",
    "prop",
    "ui"
  ]
}
```

## 当前验证范围 · proposed

一个灯房修复切片，角色/场景/UI/合成链均以真实文件交接。交接由同一Agent在隔离目录自测。

来源：用户要求完整跑潮灯小镇并检查一致性。
